﻿using System;
using System.Windows.Forms;

namespace SinhSerialDangKySuDungPhanMem
{
	public partial class Form1 : Form
	{
		public Form1()
		{
			InitializeComponent();
		}

		private void btnGiaiMa_Click(object sender, EventArgs e)
		{
			try
			{
				string[] mangDecrypt = DangKySuDungPhanMem.GiaimaSangmangString(txtMaDauVao.Text);
				txtIDCPU.Text = mangDecrypt[0];
				txtSoLanDaSuDung.Text = mangDecrypt[1];
				txtSoLanSapSuDung.Text = (Int32.Parse(mangDecrypt[1]) + 1).ToString();
			}
			catch (System.Exception ex)
			{
				MessageBox.Show(ex.Message, "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}

		private bool CheckForm()
		{
			if (String.IsNullOrEmpty(txtSoNgayChoPhep.Text))
			{
				MessageBox.Show("Số ngày cho phép sd chưa nhập", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
				txtSoNgayChoPhep.Focus();
				return false;
			}
			return true;
		}

		private void btnMaHoa_Click(object sender, EventArgs e)
		{
			try
			{
				if (!CheckForm()) return;
				// IDCPU + $ + solanupdate(da cong 1) + $ + sophutsd
				txtChuoiMaHoa.Text = DangKySuDungPhanMem.MahoaTumangString(txtIDCPU.Text,
					txtSoLanSapSuDung.Text,
					txtSoNgayChoPhep.Text);
			}
			catch (System.Exception ex)
			{
				MessageBox.Show(ex.Message, "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}
	}
}
