﻿namespace SinhSerialDangKySuDungPhanMem
{
	partial class Form1
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.txtMaDauVao = new System.Windows.Forms.TextBox();
			this.txtIDCPU = new System.Windows.Forms.TextBox();
			this.btnGiaiMa = new System.Windows.Forms.Button();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.txtSoLanDaSuDung = new System.Windows.Forms.TextBox();
			this.txtSoLanSapSuDung = new System.Windows.Forms.TextBox();
			this.label4 = new System.Windows.Forms.Label();
			this.txtSoNgayChoPhep = new System.Windows.Forms.TextBox();
			this.label5 = new System.Windows.Forms.Label();
			this.btnMaHoa = new System.Windows.Forms.Button();
			this.txtChuoiMaHoa = new System.Windows.Forms.TextBox();
			this.label6 = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// txtMaDauVao
			// 
			this.txtMaDauVao.Location = new System.Drawing.Point(159, 23);
			this.txtMaDauVao.Name = "txtMaDauVao";
			this.txtMaDauVao.Size = new System.Drawing.Size(294, 26);
			this.txtMaDauVao.TabIndex = 0;
			// 
			// txtIDCPU
			// 
			this.txtIDCPU.Location = new System.Drawing.Point(159, 65);
			this.txtIDCPU.Name = "txtIDCPU";
			this.txtIDCPU.Size = new System.Drawing.Size(294, 26);
			this.txtIDCPU.TabIndex = 1;
			// 
			// btnGiaiMa
			// 
			this.btnGiaiMa.Location = new System.Drawing.Point(159, 260);
			this.btnGiaiMa.Name = "btnGiaiMa";
			this.btnGiaiMa.Size = new System.Drawing.Size(75, 46);
			this.btnGiaiMa.TabIndex = 2;
			this.btnGiaiMa.Text = "Giải mã";
			this.btnGiaiMa.UseVisualStyleBackColor = true;
			this.btnGiaiMa.Click += new System.EventHandler(this.btnGiaiMa_Click);
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(31, 26);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(95, 20);
			this.label1.TabIndex = 3;
			this.label1.Text = "Mã đầu vào:";
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(31, 68);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(63, 20);
			this.label2.TabIndex = 3;
			this.label2.Text = "IDCPU:";
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(12, 101);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(141, 20);
			this.label3.TabIndex = 3;
			this.label3.Text = "Số lần đã sử dụng:";
			// 
			// txtSoLanDaSuDung
			// 
			this.txtSoLanDaSuDung.Location = new System.Drawing.Point(159, 98);
			this.txtSoLanDaSuDung.Name = "txtSoLanDaSuDung";
			this.txtSoLanDaSuDung.Size = new System.Drawing.Size(294, 26);
			this.txtSoLanDaSuDung.TabIndex = 1;
			// 
			// txtSoLanSapSuDung
			// 
			this.txtSoLanSapSuDung.Location = new System.Drawing.Point(159, 130);
			this.txtSoLanSapSuDung.Name = "txtSoLanSapSuDung";
			this.txtSoLanSapSuDung.ReadOnly = true;
			this.txtSoLanSapSuDung.Size = new System.Drawing.Size(294, 26);
			this.txtSoLanSapSuDung.TabIndex = 1;
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(4, 133);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(149, 20);
			this.label4.TabIndex = 3;
			this.label4.Text = "Số lần sắp sử dụng:";
			// 
			// txtSoNgayChoPhep
			// 
			this.txtSoNgayChoPhep.Location = new System.Drawing.Point(159, 162);
			this.txtSoNgayChoPhep.Name = "txtSoNgayChoPhep";
			this.txtSoNgayChoPhep.Size = new System.Drawing.Size(294, 26);
			this.txtSoNgayChoPhep.TabIndex = 1;
			// 
			// label5
			// 
			this.label5.AutoSize = true;
			this.label5.Location = new System.Drawing.Point(12, 165);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(141, 20);
			this.label5.TabIndex = 3;
			this.label5.Text = "Số ngày cho phép:";
			// 
			// btnMaHoa
			// 
			this.btnMaHoa.Location = new System.Drawing.Point(240, 260);
			this.btnMaHoa.Name = "btnMaHoa";
			this.btnMaHoa.Size = new System.Drawing.Size(75, 46);
			this.btnMaHoa.TabIndex = 2;
			this.btnMaHoa.Text = "Mã hóa";
			this.btnMaHoa.UseVisualStyleBackColor = true;
			this.btnMaHoa.Click += new System.EventHandler(this.btnMaHoa_Click);
			// 
			// txtChuoiMaHoa
			// 
			this.txtChuoiMaHoa.Location = new System.Drawing.Point(159, 194);
			this.txtChuoiMaHoa.Name = "txtChuoiMaHoa";
			this.txtChuoiMaHoa.Size = new System.Drawing.Size(294, 26);
			this.txtChuoiMaHoa.TabIndex = 1;
			// 
			// label6
			// 
			this.label6.AutoSize = true;
			this.label6.Location = new System.Drawing.Point(12, 197);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(111, 20);
			this.label6.TabIndex = 3;
			this.label6.Text = "Chuỗi mã hóa:";
			// 
			// Form1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(461, 318);
			this.Controls.Add(this.label6);
			this.Controls.Add(this.label5);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.btnMaHoa);
			this.Controls.Add(this.btnGiaiMa);
			this.Controls.Add(this.txtChuoiMaHoa);
			this.Controls.Add(this.txtSoNgayChoPhep);
			this.Controls.Add(this.txtSoLanSapSuDung);
			this.Controls.Add(this.txtSoLanDaSuDung);
			this.Controls.Add(this.txtIDCPU);
			this.Controls.Add(this.txtMaDauVao);
			this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.Name = "Form1";
			this.ShowIcon = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Sinh serial đăng ký sử dụng phần mềm";
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.TextBox txtMaDauVao;
		private System.Windows.Forms.TextBox txtIDCPU;
		private System.Windows.Forms.Button btnGiaiMa;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.TextBox txtSoLanDaSuDung;
		private System.Windows.Forms.TextBox txtSoLanSapSuDung;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.TextBox txtSoNgayChoPhep;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Button btnMaHoa;
		private System.Windows.Forms.TextBox txtChuoiMaHoa;
		private System.Windows.Forms.Label label6;
	}
}

