﻿using System.Drawing;

namespace QuanLyTiemGiatLa
{
    public class MauTrangThaiDo
    {
        public Color ChuaGiat { get; set; }
        public Color DaGiat { get; set; }
        public Color GhiChu { get; set; }
        public Color DaTra { get; set; }
        public Color PhieuHuy { get; set; }
        
        public MauTrangThaiDo()
        {
            //ChuaGiat = Color.Red;
            //DaGiat = Color.Blue;
            //GhiChu = Color.Orange;
            //DaTra = Color.Green;
        }
    }
}
