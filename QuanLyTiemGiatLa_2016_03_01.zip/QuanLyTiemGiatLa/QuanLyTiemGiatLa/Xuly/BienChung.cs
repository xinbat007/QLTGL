﻿using System;
namespace QuanLyTiemGiatLa
{
	public class BienChung
	{
		public static Entity.UserEntity userCurrent;
		public static Boolean Q_Them;
		public static Boolean Q_Sua;
		public static Boolean Q_Xoa;
		public static Boolean Q_Select;
		public static Entity.CheckKeyEntity checkKey;
		public static Boolean DaMuaFull;
		public static Boolean DuocPhepSuDung;
        public static MauTrangThaiDo mautrangthaido;
		public static bool isTrienKhai;
		public static bool isToanManHinh = false;
	}
}
