﻿namespace QuanLyTiemGiatLa.Danhmuc
{
	partial class frmDoanhThuCuaTiem
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmDoanhThuCuaTiem));
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.txtTongCong = new System.Windows.Forms.TextBox();
            this.btnSearch = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.dtpDenNgay = new System.Windows.Forms.DateTimePicker();
            this.dtpTuNgay = new System.Windows.Forms.DateTimePicker();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.dgvDSThuNhap = new System.Windows.Forms.DataGridView();
            this.ngayLapDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tongTienSauGiamGiaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TongTienHuyHoaDon = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TongTienPhiVanChuyen = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TongTienCuoiCung = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bndsrcDSThuNhap = new System.Windows.Forms.BindingSource(this.components);
            this.dgvDSPhieuTrongNgay = new System.Windows.Forms.DataGridView();
            this.maPhieuDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.maKhachHangDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ngayLapDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ngayHenTraDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tenKhachHangDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.giamGiaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PhiGiaoNhan = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TongTien = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.daThanhToanDataGridViewCheckBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.IsPhieuHuy = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.ghiChuDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bndsrcDSPhieuTrongNgay = new System.Windows.Forms.BindingSource(this.components);
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnThoat = new System.Windows.Forms.Button();
            this.btnInDoanhThu = new System.Windows.Forms.Button();
            this.btnCollapse = new System.Windows.Forms.Button();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDSThuNhap)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bndsrcDSThuNhap)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDSPhieuTrongNgay)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bndsrcDSPhieuTrongNgay)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // splitContainer1
            // 
            this.splitContainer1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.txtTongCong);
            this.splitContainer1.Panel1.Controls.Add(this.btnSearch);
            this.splitContainer1.Panel1.Controls.Add(this.groupBox1);
            this.splitContainer1.Panel1.Controls.Add(this.label3);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.splitContainer2);
            this.splitContainer1.Panel2.Controls.Add(this.panel1);
            this.splitContainer1.Size = new System.Drawing.Size(984, 562);
            this.splitContainer1.SplitterDistance = 151;
            this.splitContainer1.TabIndex = 0;
            // 
            // txtTongCong
            // 
            this.txtTongCong.BackColor = System.Drawing.SystemColors.Control;
            this.txtTongCong.Font = new System.Drawing.Font("Courier New", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTongCong.ForeColor = System.Drawing.Color.Red;
            this.txtTongCong.Location = new System.Drawing.Point(10, 238);
            this.txtTongCong.Name = "txtTongCong";
            this.txtTongCong.ReadOnly = true;
            this.txtTongCong.Size = new System.Drawing.Size(127, 26);
            this.txtTongCong.TabIndex = 2;
            this.txtTongCong.Text = "0";
            this.txtTongCong.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // btnSearch
            // 
            this.btnSearch.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSearch.Image = global::QuanLyTiemGiatLa.Properties.Resources._49;
            this.btnSearch.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSearch.Location = new System.Drawing.Point(55, 150);
            this.btnSearch.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(92, 48);
            this.btnSearch.TabIndex = 1;
            this.btnSearch.Text = "Tì&m";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Controls.Add(this.dtpDenNgay);
            this.groupBox1.Controls.Add(this.dtpTuNgay);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(4, 4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(143, 142);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            // 
            // dtpDenNgay
            // 
            this.dtpDenNgay.CustomFormat = "dd/MM/yyyy";
            this.dtpDenNgay.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpDenNgay.Location = new System.Drawing.Point(6, 100);
            this.dtpDenNgay.Name = "dtpDenNgay";
            this.dtpDenNgay.Size = new System.Drawing.Size(127, 24);
            this.dtpDenNgay.TabIndex = 1;
            // 
            // dtpTuNgay
            // 
            this.dtpTuNgay.CustomFormat = "dd/MM/yyyy";
            this.dtpTuNgay.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpTuNgay.Location = new System.Drawing.Point(6, 42);
            this.dtpTuNgay.Name = "dtpTuNgay";
            this.dtpTuNgay.Size = new System.Drawing.Size(127, 24);
            this.dtpTuNgay.TabIndex = 0;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(2, 74);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(74, 18);
            this.label2.TabIndex = 0;
            this.label2.Text = "Đến ngày:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(2, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(64, 18);
            this.label1.TabIndex = 0;
            this.label1.Text = "Từ ngày:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 210);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(83, 18);
            this.label3.TabIndex = 0;
            this.label3.Text = "Tổng cộng:";
            // 
            // splitContainer2
            // 
            this.splitContainer2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.splitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer2.Location = new System.Drawing.Point(0, 0);
            this.splitContainer2.Name = "splitContainer2";
            this.splitContainer2.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.Controls.Add(this.dgvDSThuNhap);
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.Controls.Add(this.dgvDSPhieuTrongNgay);
            this.splitContainer2.Size = new System.Drawing.Size(829, 500);
            this.splitContainer2.SplitterDistance = 198;
            this.splitContainer2.TabIndex = 1;
            // 
            // dgvDSThuNhap
            // 
            this.dgvDSThuNhap.AllowUserToAddRows = false;
            this.dgvDSThuNhap.AllowUserToDeleteRows = false;
            this.dgvDSThuNhap.AutoGenerateColumns = false;
            this.dgvDSThuNhap.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dgvDSThuNhap.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDSThuNhap.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ngayLapDataGridViewTextBoxColumn1,
            this.tongTienSauGiamGiaDataGridViewTextBoxColumn,
            this.TongTienHuyHoaDon,
            this.TongTienPhiVanChuyen,
            this.TongTienCuoiCung});
            this.dgvDSThuNhap.DataSource = this.bndsrcDSThuNhap;
            this.dgvDSThuNhap.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvDSThuNhap.Location = new System.Drawing.Point(0, 0);
            this.dgvDSThuNhap.Name = "dgvDSThuNhap";
            this.dgvDSThuNhap.ReadOnly = true;
            this.dgvDSThuNhap.RowHeadersWidth = 25;
            this.dgvDSThuNhap.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvDSThuNhap.Size = new System.Drawing.Size(825, 194);
            this.dgvDSThuNhap.TabIndex = 0;
            // 
            // ngayLapDataGridViewTextBoxColumn1
            // 
            this.ngayLapDataGridViewTextBoxColumn1.DataPropertyName = "NgayLap";
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.Format = "dd/MM/yyyy";
            this.ngayLapDataGridViewTextBoxColumn1.DefaultCellStyle = dataGridViewCellStyle1;
            this.ngayLapDataGridViewTextBoxColumn1.HeaderText = "Ngày";
            this.ngayLapDataGridViewTextBoxColumn1.Name = "ngayLapDataGridViewTextBoxColumn1";
            this.ngayLapDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // tongTienSauGiamGiaDataGridViewTextBoxColumn
            // 
            this.tongTienSauGiamGiaDataGridViewTextBoxColumn.DataPropertyName = "TongTienSauGiamGia";
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Courier New", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.Format = "N0";
            this.tongTienSauGiamGiaDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle2;
            this.tongTienSauGiamGiaDataGridViewTextBoxColumn.HeaderText = "Tổng thu (đã giảm)";
            this.tongTienSauGiamGiaDataGridViewTextBoxColumn.Name = "tongTienSauGiamGiaDataGridViewTextBoxColumn";
            this.tongTienSauGiamGiaDataGridViewTextBoxColumn.ReadOnly = true;
            this.tongTienSauGiamGiaDataGridViewTextBoxColumn.Width = 160;
            // 
            // TongTienHuyHoaDon
            // 
            this.TongTienHuyHoaDon.DataPropertyName = "TongTienHuyHoaDon";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Courier New", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.Format = "N0";
            this.TongTienHuyHoaDon.DefaultCellStyle = dataGridViewCellStyle3;
            this.TongTienHuyHoaDon.HeaderText = "Tổng tiền hđ hủy";
            this.TongTienHuyHoaDon.Name = "TongTienHuyHoaDon";
            this.TongTienHuyHoaDon.ReadOnly = true;
            this.TongTienHuyHoaDon.Width = 150;
            // 
            // TongTienPhiVanChuyen
            // 
            this.TongTienPhiVanChuyen.DataPropertyName = "TongTienPhiVanChuyen";
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Courier New", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.Format = "N0";
            this.TongTienPhiVanChuyen.DefaultCellStyle = dataGridViewCellStyle4;
            this.TongTienPhiVanChuyen.HeaderText = "Tổng tiền phí vc";
            this.TongTienPhiVanChuyen.Name = "TongTienPhiVanChuyen";
            this.TongTienPhiVanChuyen.ReadOnly = true;
            this.TongTienPhiVanChuyen.Width = 150;
            // 
            // TongTienCuoiCung
            // 
            this.TongTienCuoiCung.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.TongTienCuoiCung.DataPropertyName = "TongTienCuoiCung";
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Courier New", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.Red;
            dataGridViewCellStyle5.Format = "N0";
            this.TongTienCuoiCung.DefaultCellStyle = dataGridViewCellStyle5;
            this.TongTienCuoiCung.HeaderText = "Tổng thu cuối cùng";
            this.TongTienCuoiCung.Name = "TongTienCuoiCung";
            this.TongTienCuoiCung.ReadOnly = true;
            // 
            // bndsrcDSThuNhap
            // 
            this.bndsrcDSThuNhap.DataSource = typeof(Entity.ListThuNhapTrongNgayEntity);
            this.bndsrcDSThuNhap.CurrentChanged += new System.EventHandler(this.bndsrcDSThuNhap_CurrentChanged);
            // 
            // dgvDSPhieuTrongNgay
            // 
            this.dgvDSPhieuTrongNgay.AllowUserToAddRows = false;
            this.dgvDSPhieuTrongNgay.AllowUserToDeleteRows = false;
            this.dgvDSPhieuTrongNgay.AutoGenerateColumns = false;
            this.dgvDSPhieuTrongNgay.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dgvDSPhieuTrongNgay.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDSPhieuTrongNgay.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.maPhieuDataGridViewTextBoxColumn,
            this.maKhachHangDataGridViewTextBoxColumn,
            this.ngayLapDataGridViewTextBoxColumn,
            this.ngayHenTraDataGridViewTextBoxColumn,
            this.tenKhachHangDataGridViewTextBoxColumn,
            this.giamGiaDataGridViewTextBoxColumn,
            this.PhiGiaoNhan,
            this.TongTien,
            this.daThanhToanDataGridViewCheckBoxColumn,
            this.IsPhieuHuy,
            this.ghiChuDataGridViewTextBoxColumn});
            this.dgvDSPhieuTrongNgay.DataSource = this.bndsrcDSPhieuTrongNgay;
            this.dgvDSPhieuTrongNgay.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvDSPhieuTrongNgay.Location = new System.Drawing.Point(0, 0);
            this.dgvDSPhieuTrongNgay.Name = "dgvDSPhieuTrongNgay";
            this.dgvDSPhieuTrongNgay.ReadOnly = true;
            this.dgvDSPhieuTrongNgay.RowHeadersWidth = 25;
            this.dgvDSPhieuTrongNgay.Size = new System.Drawing.Size(825, 294);
            this.dgvDSPhieuTrongNgay.TabIndex = 0;
            // 
            // maPhieuDataGridViewTextBoxColumn
            // 
            this.maPhieuDataGridViewTextBoxColumn.DataPropertyName = "MaPhieu";
            this.maPhieuDataGridViewTextBoxColumn.Frozen = true;
            this.maPhieuDataGridViewTextBoxColumn.HeaderText = "Mã phiếu";
            this.maPhieuDataGridViewTextBoxColumn.Name = "maPhieuDataGridViewTextBoxColumn";
            this.maPhieuDataGridViewTextBoxColumn.ReadOnly = true;
            this.maPhieuDataGridViewTextBoxColumn.Width = 90;
            // 
            // maKhachHangDataGridViewTextBoxColumn
            // 
            this.maKhachHangDataGridViewTextBoxColumn.DataPropertyName = "MaKhachHang";
            this.maKhachHangDataGridViewTextBoxColumn.HeaderText = "MaKhachHang";
            this.maKhachHangDataGridViewTextBoxColumn.Name = "maKhachHangDataGridViewTextBoxColumn";
            this.maKhachHangDataGridViewTextBoxColumn.ReadOnly = true;
            this.maKhachHangDataGridViewTextBoxColumn.Visible = false;
            // 
            // ngayLapDataGridViewTextBoxColumn
            // 
            this.ngayLapDataGridViewTextBoxColumn.DataPropertyName = "NgayLap";
            this.ngayLapDataGridViewTextBoxColumn.HeaderText = "NgayLap";
            this.ngayLapDataGridViewTextBoxColumn.Name = "ngayLapDataGridViewTextBoxColumn";
            this.ngayLapDataGridViewTextBoxColumn.ReadOnly = true;
            this.ngayLapDataGridViewTextBoxColumn.Visible = false;
            // 
            // ngayHenTraDataGridViewTextBoxColumn
            // 
            this.ngayHenTraDataGridViewTextBoxColumn.DataPropertyName = "NgayHenTra";
            this.ngayHenTraDataGridViewTextBoxColumn.HeaderText = "NgayHenTra";
            this.ngayHenTraDataGridViewTextBoxColumn.Name = "ngayHenTraDataGridViewTextBoxColumn";
            this.ngayHenTraDataGridViewTextBoxColumn.ReadOnly = true;
            this.ngayHenTraDataGridViewTextBoxColumn.Visible = false;
            // 
            // tenKhachHangDataGridViewTextBoxColumn
            // 
            this.tenKhachHangDataGridViewTextBoxColumn.DataPropertyName = "TenKhachHang";
            this.tenKhachHangDataGridViewTextBoxColumn.HeaderText = "Khách hàng";
            this.tenKhachHangDataGridViewTextBoxColumn.Name = "tenKhachHangDataGridViewTextBoxColumn";
            this.tenKhachHangDataGridViewTextBoxColumn.ReadOnly = true;
            this.tenKhachHangDataGridViewTextBoxColumn.Width = 120;
            // 
            // giamGiaDataGridViewTextBoxColumn
            // 
            this.giamGiaDataGridViewTextBoxColumn.DataPropertyName = "GiamGia";
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.giamGiaDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle6;
            this.giamGiaDataGridViewTextBoxColumn.HeaderText = "Giảm giá (%)";
            this.giamGiaDataGridViewTextBoxColumn.Name = "giamGiaDataGridViewTextBoxColumn";
            this.giamGiaDataGridViewTextBoxColumn.ReadOnly = true;
            this.giamGiaDataGridViewTextBoxColumn.Width = 60;
            // 
            // PhiGiaoNhan
            // 
            this.PhiGiaoNhan.DataPropertyName = "PhiGiaoNhan";
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.PhiGiaoNhan.DefaultCellStyle = dataGridViewCellStyle7;
            this.PhiGiaoNhan.HeaderText = "Phí vc (%)";
            this.PhiGiaoNhan.Name = "PhiGiaoNhan";
            this.PhiGiaoNhan.ReadOnly = true;
            this.PhiGiaoNhan.Width = 80;
            // 
            // TongTien
            // 
            this.TongTien.DataPropertyName = "TongTien";
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Courier New", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.Color.Red;
            dataGridViewCellStyle8.Format = "N0";
            this.TongTien.DefaultCellStyle = dataGridViewCellStyle8;
            this.TongTien.HeaderText = "Tổng thu (đã giảm)";
            this.TongTien.Name = "TongTien";
            this.TongTien.ReadOnly = true;
            this.TongTien.Width = 120;
            // 
            // daThanhToanDataGridViewCheckBoxColumn
            // 
            this.daThanhToanDataGridViewCheckBoxColumn.DataPropertyName = "DaThanhToan";
            this.daThanhToanDataGridViewCheckBoxColumn.HeaderText = "Đã thanh toán";
            this.daThanhToanDataGridViewCheckBoxColumn.Name = "daThanhToanDataGridViewCheckBoxColumn";
            this.daThanhToanDataGridViewCheckBoxColumn.ReadOnly = true;
            this.daThanhToanDataGridViewCheckBoxColumn.Width = 70;
            // 
            // IsPhieuHuy
            // 
            this.IsPhieuHuy.DataPropertyName = "IsPhieuHuy";
            this.IsPhieuHuy.HeaderText = "Phiếu hủy";
            this.IsPhieuHuy.Name = "IsPhieuHuy";
            this.IsPhieuHuy.ReadOnly = true;
            this.IsPhieuHuy.Width = 70;
            // 
            // ghiChuDataGridViewTextBoxColumn
            // 
            this.ghiChuDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.ghiChuDataGridViewTextBoxColumn.DataPropertyName = "GhiChu";
            this.ghiChuDataGridViewTextBoxColumn.HeaderText = "Ghi chú";
            this.ghiChuDataGridViewTextBoxColumn.Name = "ghiChuDataGridViewTextBoxColumn";
            this.ghiChuDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // bndsrcDSPhieuTrongNgay
            // 
            this.bndsrcDSPhieuTrongNgay.DataSource = typeof(Entity.ListPhieuEntity);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btnThoat);
            this.panel1.Controls.Add(this.btnInDoanhThu);
            this.panel1.Controls.Add(this.btnCollapse);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(0, 500);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(829, 62);
            this.panel1.TabIndex = 0;
            // 
            // btnThoat
            // 
            this.btnThoat.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnThoat.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnThoat.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThoat.Image = global::QuanLyTiemGiatLa.Properties.Resources.Exit16;
            this.btnThoat.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnThoat.Location = new System.Drawing.Point(725, 6);
            this.btnThoat.Margin = new System.Windows.Forms.Padding(4);
            this.btnThoat.Name = "btnThoat";
            this.btnThoat.Size = new System.Drawing.Size(91, 48);
            this.btnThoat.TabIndex = 1;
            this.btnThoat.Text = "&Thoát";
            this.btnThoat.UseVisualStyleBackColor = true;
            this.btnThoat.Click += new System.EventHandler(this.btnThoat_Click);
            // 
            // btnInDoanhThu
            // 
            this.btnInDoanhThu.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnInDoanhThu.Image = global::QuanLyTiemGiatLa.Properties.Resources.iCandy_Junior_02316;
            this.btnInDoanhThu.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnInDoanhThu.Location = new System.Drawing.Point(602, 6);
            this.btnInDoanhThu.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnInDoanhThu.Name = "btnInDoanhThu";
            this.btnInDoanhThu.Size = new System.Drawing.Size(116, 48);
            this.btnInDoanhThu.TabIndex = 0;
            this.btnInDoanhThu.Text = "&In doanh thu";
            this.btnInDoanhThu.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnInDoanhThu.UseVisualStyleBackColor = true;
            this.btnInDoanhThu.Click += new System.EventHandler(this.btnInDoanhThu_Click);
            // 
            // btnCollapse
            // 
            this.btnCollapse.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnCollapse.Location = new System.Drawing.Point(3, 6);
            this.btnCollapse.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnCollapse.Name = "btnCollapse";
            this.btnCollapse.Size = new System.Drawing.Size(60, 48);
            this.btnCollapse.TabIndex = 0;
            this.btnCollapse.Text = "<<";
            this.btnCollapse.UseVisualStyleBackColor = true;
            this.btnCollapse.Click += new System.EventHandler(this.btnCollapse_Click);
            // 
            // frmDoanhThuCuaTiem
            // 
            this.AcceptButton = this.btnSearch;
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnThoat;
            this.ClientSize = new System.Drawing.Size(984, 562);
            this.Controls.Add(this.splitContainer1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmDoanhThuCuaTiem";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Thống kê doanh thu của tiệm";
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel2.ResumeLayout(false);
            this.splitContainer2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDSThuNhap)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bndsrcDSThuNhap)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDSPhieuTrongNgay)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bndsrcDSPhieuTrongNgay)).EndInit();
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.SplitContainer splitContainer1;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.DateTimePicker dtpDenNgay;
		private System.Windows.Forms.DateTimePicker dtpTuNgay;
		private System.Windows.Forms.Button btnSearch;
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.Button btnCollapse;
		private System.Windows.Forms.Button btnThoat;
		private System.Windows.Forms.SplitContainer splitContainer2;
		private System.Windows.Forms.DataGridView dgvDSPhieuTrongNgay;
		private System.Windows.Forms.BindingSource bndsrcDSPhieuTrongNgay;
		private System.Windows.Forms.DataGridView dgvDSThuNhap;
		private System.Windows.Forms.BindingSource bndsrcDSThuNhap;
		private System.Windows.Forms.TextBox txtTongCong;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Button btnInDoanhThu;
		private System.Windows.Forms.DataGridViewTextBoxColumn maPhieuDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn maKhachHangDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn ngayLapDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn ngayHenTraDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn tenKhachHangDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn giamGiaDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn PhiGiaoNhan;
		private System.Windows.Forms.DataGridViewTextBoxColumn TongTien;
		private System.Windows.Forms.DataGridViewCheckBoxColumn daThanhToanDataGridViewCheckBoxColumn;
		private System.Windows.Forms.DataGridViewCheckBoxColumn IsPhieuHuy;
		private System.Windows.Forms.DataGridViewTextBoxColumn ghiChuDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn ngayLapDataGridViewTextBoxColumn1;
		private System.Windows.Forms.DataGridViewTextBoxColumn tongTienSauGiamGiaDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn TongTienHuyHoaDon;
		private System.Windows.Forms.DataGridViewTextBoxColumn TongTienPhiVanChuyen;
		private System.Windows.Forms.DataGridViewTextBoxColumn TongTienCuoiCung;
	}
}