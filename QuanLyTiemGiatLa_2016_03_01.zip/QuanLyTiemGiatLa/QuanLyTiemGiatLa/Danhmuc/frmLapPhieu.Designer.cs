﻿namespace QuanLyTiemGiatLa.Danhmuc
{
	partial class frmLapPhieu
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmLapPhieu));
			this.txtTenKhachHang = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.dtpNgayLap = new System.Windows.Forms.DateTimePicker();
			this.dtpNgayHenTra = new System.Windows.Forms.DateTimePicker();
			this.dgvDSDo = new System.Windows.Forms.DataGridView();
			this.iDChiTietPhieuDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.maPhieuDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.maHangDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.maKieuGiatDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.tenHangDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.tenKieuGiatDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.soluongDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.donGiaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.GhiChu = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
			this.mnuXoa = new System.Windows.Forms.ToolStripMenuItem();
			this.bndsrcDSCTPhieu = new System.Windows.Forms.BindingSource(this.components);
			this.panel1 = new System.Windows.Forms.Panel();
			this.txtTongSoSanPham = new System.Windows.Forms.TextBox();
			this.label15 = new System.Windows.Forms.Label();
			this.label14 = new System.Windows.Forms.Label();
			this.txtUserName = new System.Windows.Forms.TextBox();
			this.btnCatDo = new System.Windows.Forms.Button();
			this.btnThoat = new System.Windows.Forms.Button();
			this.btnXoaDo = new System.Windows.Forms.Button();
			this.btnThemDo = new System.Windows.Forms.Button();
			this.label5 = new System.Windows.Forms.Label();
			this.lblTongTien = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.txtMaPhieu = new System.Windows.Forms.TextBox();
			this.label6 = new System.Windows.Forms.Label();
			this.nudGiamGia = new System.Windows.Forms.NumericUpDown();
			this.label7 = new System.Windows.Forms.Label();
			this.txtLoaiKhach = new System.Windows.Forms.TextBox();
			this.label8 = new System.Windows.Forms.Label();
			this.label9 = new System.Windows.Forms.Label();
			this.lblThanhTien = new System.Windows.Forms.Label();
			this.label10 = new System.Windows.Forms.Label();
			this.txtGhiChu = new System.Windows.Forms.TextBox();
			this.label11 = new System.Windows.Forms.Label();
			this.label12 = new System.Windows.Forms.Label();
			this.txtSoTienKHDaTra = new System.Windows.Forms.TextBox();
			this.lblTienTraLai = new System.Windows.Forms.Label();
			this.btnInHoaDon = new System.Windows.Forms.Button();
			this.btnGhi = new System.Windows.Forms.Button();
			this.btnFind = new System.Windows.Forms.Button();
			this.dgvDSPhieuSlot = new System.Windows.Forms.DataGridView();
			this.maPhieuDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.sTTDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.maHangDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.maKieuGiatDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.maHienThiDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.MaVach = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.tenHangDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.SoHieuSanPham = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.tenKieuGiatDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.khoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.slotDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.GhiChuSlot = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.daTraDataGridViewCheckBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
			this.ThoiDiemLuu = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.NgayTraDataGridViewCheckBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.bndsrcDSPhieuSlot = new System.Windows.Forms.BindingSource(this.components);
			this.chkDaThanhToan = new System.Windows.Forms.CheckBox();
			this.label13 = new System.Windows.Forms.Label();
			this.txtMaVachDauTien = new System.Windows.Forms.TextBox();
			this.label16 = new System.Windows.Forms.Label();
			this.txtMaVachCuoi = new System.Windows.Forms.TextBox();
			this.chkPhiGiaoNhan = new System.Windows.Forms.CheckBox();
			((System.ComponentModel.ISupportInitialize)(this.dgvDSDo)).BeginInit();
			this.contextMenuStrip1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.bndsrcDSCTPhieu)).BeginInit();
			this.panel1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.nudGiamGia)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.dgvDSPhieuSlot)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.bndsrcDSPhieuSlot)).BeginInit();
			this.SuspendLayout();
			// 
			// txtTenKhachHang
			// 
			this.txtTenKhachHang.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txtTenKhachHang.Location = new System.Drawing.Point(115, 14);
			this.txtTenKhachHang.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.txtTenKhachHang.Name = "txtTenKhachHang";
			this.txtTenKhachHang.Size = new System.Drawing.Size(164, 26);
			this.txtTenKhachHang.TabIndex = 0;
			this.txtTenKhachHang.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtTenKhachHang_KeyDown);
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(13, 17);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(98, 20);
			this.label1.TabIndex = 5;
			this.label1.Text = "Khách hàng:";
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(13, 87);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(74, 20);
			this.label2.TabIndex = 6;
			this.label2.Text = "Ngày lập:";
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(13, 122);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(103, 20);
			this.label3.TabIndex = 8;
			this.label3.Text = "Ngày hẹn trả:";
			// 
			// dtpNgayLap
			// 
			this.dtpNgayLap.CustomFormat = "dd/MM/yyyy HH:mm";
			this.dtpNgayLap.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			this.dtpNgayLap.Location = new System.Drawing.Point(115, 83);
			this.dtpNgayLap.Name = "dtpNgayLap";
			this.dtpNgayLap.Size = new System.Drawing.Size(164, 26);
			this.dtpNgayLap.TabIndex = 3;
			this.dtpNgayLap.KeyDown += new System.Windows.Forms.KeyEventHandler(this.dtpNgayLap_KeyDown);
			// 
			// dtpNgayHenTra
			// 
			this.dtpNgayHenTra.Checked = false;
			this.dtpNgayHenTra.CustomFormat = "dd/MM/yyyy";
			this.dtpNgayHenTra.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			this.dtpNgayHenTra.Location = new System.Drawing.Point(115, 117);
			this.dtpNgayHenTra.Name = "dtpNgayHenTra";
			this.dtpNgayHenTra.Size = new System.Drawing.Size(164, 26);
			this.dtpNgayHenTra.TabIndex = 4;
			this.dtpNgayHenTra.KeyDown += new System.Windows.Forms.KeyEventHandler(this.dtpNgayHenTra_KeyDown);
			// 
			// dgvDSDo
			// 
			this.dgvDSDo.AllowUserToAddRows = false;
			this.dgvDSDo.AllowUserToDeleteRows = false;
			this.dgvDSDo.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
						| System.Windows.Forms.AnchorStyles.Right)));
			this.dgvDSDo.AutoGenerateColumns = false;
			this.dgvDSDo.BackgroundColor = System.Drawing.SystemColors.Control;
			this.dgvDSDo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dgvDSDo.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iDChiTietPhieuDataGridViewTextBoxColumn,
            this.maPhieuDataGridViewTextBoxColumn,
            this.maHangDataGridViewTextBoxColumn,
            this.maKieuGiatDataGridViewTextBoxColumn,
            this.tenHangDataGridViewTextBoxColumn,
            this.tenKieuGiatDataGridViewTextBoxColumn,
            this.soluongDataGridViewTextBoxColumn,
            this.donGiaDataGridViewTextBoxColumn,
            this.GhiChu});
			this.dgvDSDo.ContextMenuStrip = this.contextMenuStrip1;
			this.dgvDSDo.DataSource = this.bndsrcDSCTPhieu;
			this.dgvDSDo.Location = new System.Drawing.Point(4, 186);
			this.dgvDSDo.MultiSelect = false;
			this.dgvDSDo.Name = "dgvDSDo";
			this.dgvDSDo.ReadOnly = true;
			this.dgvDSDo.RowHeadersWidth = 20;
			this.dgvDSDo.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
			this.dgvDSDo.Size = new System.Drawing.Size(857, 202);
			this.dgvDSDo.TabIndex = 18;
			// 
			// iDChiTietPhieuDataGridViewTextBoxColumn
			// 
			this.iDChiTietPhieuDataGridViewTextBoxColumn.DataPropertyName = "IDChiTietPhieu";
			this.iDChiTietPhieuDataGridViewTextBoxColumn.HeaderText = "IDChiTietPhieu";
			this.iDChiTietPhieuDataGridViewTextBoxColumn.Name = "iDChiTietPhieuDataGridViewTextBoxColumn";
			this.iDChiTietPhieuDataGridViewTextBoxColumn.ReadOnly = true;
			this.iDChiTietPhieuDataGridViewTextBoxColumn.Visible = false;
			// 
			// maPhieuDataGridViewTextBoxColumn
			// 
			this.maPhieuDataGridViewTextBoxColumn.DataPropertyName = "MaPhieu";
			this.maPhieuDataGridViewTextBoxColumn.HeaderText = "MaPhieu";
			this.maPhieuDataGridViewTextBoxColumn.Name = "maPhieuDataGridViewTextBoxColumn";
			this.maPhieuDataGridViewTextBoxColumn.ReadOnly = true;
			this.maPhieuDataGridViewTextBoxColumn.Visible = false;
			// 
			// maHangDataGridViewTextBoxColumn
			// 
			this.maHangDataGridViewTextBoxColumn.DataPropertyName = "MaHang";
			this.maHangDataGridViewTextBoxColumn.HeaderText = "MaHang";
			this.maHangDataGridViewTextBoxColumn.Name = "maHangDataGridViewTextBoxColumn";
			this.maHangDataGridViewTextBoxColumn.ReadOnly = true;
			this.maHangDataGridViewTextBoxColumn.Visible = false;
			// 
			// maKieuGiatDataGridViewTextBoxColumn
			// 
			this.maKieuGiatDataGridViewTextBoxColumn.DataPropertyName = "MaKieuGiat";
			this.maKieuGiatDataGridViewTextBoxColumn.HeaderText = "MaKieuGiat";
			this.maKieuGiatDataGridViewTextBoxColumn.Name = "maKieuGiatDataGridViewTextBoxColumn";
			this.maKieuGiatDataGridViewTextBoxColumn.ReadOnly = true;
			this.maKieuGiatDataGridViewTextBoxColumn.Visible = false;
			// 
			// tenHangDataGridViewTextBoxColumn
			// 
			this.tenHangDataGridViewTextBoxColumn.DataPropertyName = "TenHang";
			this.tenHangDataGridViewTextBoxColumn.HeaderText = "Tên đồ";
			this.tenHangDataGridViewTextBoxColumn.Name = "tenHangDataGridViewTextBoxColumn";
			this.tenHangDataGridViewTextBoxColumn.ReadOnly = true;
			this.tenHangDataGridViewTextBoxColumn.Width = 200;
			// 
			// tenKieuGiatDataGridViewTextBoxColumn
			// 
			this.tenKieuGiatDataGridViewTextBoxColumn.DataPropertyName = "TenKieuGiat";
			this.tenKieuGiatDataGridViewTextBoxColumn.HeaderText = "Kiểu giặt";
			this.tenKieuGiatDataGridViewTextBoxColumn.Name = "tenKieuGiatDataGridViewTextBoxColumn";
			this.tenKieuGiatDataGridViewTextBoxColumn.ReadOnly = true;
			// 
			// soluongDataGridViewTextBoxColumn
			// 
			this.soluongDataGridViewTextBoxColumn.DataPropertyName = "Soluong";
			dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
			this.soluongDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle1;
			this.soluongDataGridViewTextBoxColumn.HeaderText = "Số lượng";
			this.soluongDataGridViewTextBoxColumn.Name = "soluongDataGridViewTextBoxColumn";
			this.soluongDataGridViewTextBoxColumn.ReadOnly = true;
			this.soluongDataGridViewTextBoxColumn.Width = 95;
			// 
			// donGiaDataGridViewTextBoxColumn
			// 
			this.donGiaDataGridViewTextBoxColumn.DataPropertyName = "DonGia";
			dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle2.Format = "N0";
			this.donGiaDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle2;
			this.donGiaDataGridViewTextBoxColumn.HeaderText = "Đơn giá";
			this.donGiaDataGridViewTextBoxColumn.Name = "donGiaDataGridViewTextBoxColumn";
			this.donGiaDataGridViewTextBoxColumn.ReadOnly = true;
			this.donGiaDataGridViewTextBoxColumn.Width = 120;
			// 
			// GhiChu
			// 
			this.GhiChu.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
			this.GhiChu.DataPropertyName = "GhiChu";
			this.GhiChu.HeaderText = "Ghi chú";
			this.GhiChu.Name = "GhiChu";
			this.GhiChu.ReadOnly = true;
			// 
			// contextMenuStrip1
			// 
			this.contextMenuStrip1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuXoa});
			this.contextMenuStrip1.Name = "contextMenuStrip1";
			this.contextMenuStrip1.Size = new System.Drawing.Size(107, 30);
			this.contextMenuStrip1.Opening += new System.ComponentModel.CancelEventHandler(this.contextMenuStrip1_Opening);
			// 
			// mnuXoa
			// 
			this.mnuXoa.Name = "mnuXoa";
			this.mnuXoa.Size = new System.Drawing.Size(106, 26);
			this.mnuXoa.Text = "Xóa";
			this.mnuXoa.Click += new System.EventHandler(this.mnuXoa_Click);
			// 
			// bndsrcDSCTPhieu
			// 
			this.bndsrcDSCTPhieu.DataSource = typeof(Entity.ListChiTietPhieuEntity);
			// 
			// panel1
			// 
			this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
						| System.Windows.Forms.AnchorStyles.Right)));
			this.panel1.Controls.Add(this.txtTongSoSanPham);
			this.panel1.Controls.Add(this.label15);
			this.panel1.Controls.Add(this.label14);
			this.panel1.Controls.Add(this.txtUserName);
			this.panel1.Controls.Add(this.btnCatDo);
			this.panel1.Controls.Add(this.btnThoat);
			this.panel1.Controls.Add(this.btnXoaDo);
			this.panel1.Controls.Add(this.btnThemDo);
			this.panel1.Location = new System.Drawing.Point(0, 394);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(864, 67);
			this.panel1.TabIndex = 19;
			// 
			// txtTongSoSanPham
			// 
			this.txtTongSoSanPham.Location = new System.Drawing.Point(283, 36);
			this.txtTongSoSanPham.Name = "txtTongSoSanPham";
			this.txtTongSoSanPham.ReadOnly = true;
			this.txtTongSoSanPham.Size = new System.Drawing.Size(195, 26);
			this.txtTongSoSanPham.TabIndex = 2;
			this.txtTongSoSanPham.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			// 
			// label15
			// 
			this.label15.AutoSize = true;
			this.label15.Location = new System.Drawing.Point(191, 9);
			this.label15.Name = "label15";
			this.label15.Size = new System.Drawing.Size(79, 20);
			this.label15.TabIndex = 8;
			this.label15.Text = "Người lập:";
			// 
			// label14
			// 
			this.label14.AutoSize = true;
			this.label14.Location = new System.Drawing.Point(126, 39);
			this.label14.Name = "label14";
			this.label14.Size = new System.Drawing.Size(144, 20);
			this.label14.TabIndex = 8;
			this.label14.Text = "Tổng số sản phẩm:";
			// 
			// txtUserName
			// 
			this.txtUserName.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.txtUserName.Enabled = false;
			this.txtUserName.Location = new System.Drawing.Point(283, 6);
			this.txtUserName.Name = "txtUserName";
			this.txtUserName.Size = new System.Drawing.Size(195, 26);
			this.txtUserName.TabIndex = 1;
			// 
			// btnCatDo
			// 
			this.btnCatDo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.btnCatDo.Image = global::QuanLyTiemGiatLa.Properties.Resources.ark232;
			this.btnCatDo.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnCatDo.Location = new System.Drawing.Point(11, 6);
			this.btnCatDo.Name = "btnCatDo";
			this.btnCatDo.Size = new System.Drawing.Size(100, 53);
			this.btnCatDo.TabIndex = 0;
			this.btnCatDo.Text = "&Cất đồ";
			this.btnCatDo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnCatDo.UseVisualStyleBackColor = true;
			this.btnCatDo.Click += new System.EventHandler(this.btnCatDo_Click);
			// 
			// btnThoat
			// 
			this.btnThoat.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.btnThoat.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.btnThoat.Image = global::QuanLyTiemGiatLa.Properties.Resources.Exit16;
			this.btnThoat.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnThoat.Location = new System.Drawing.Point(763, 6);
			this.btnThoat.Name = "btnThoat";
			this.btnThoat.Size = new System.Drawing.Size(89, 58);
			this.btnThoat.TabIndex = 5;
			this.btnThoat.Text = "&Thoát";
			this.btnThoat.UseVisualStyleBackColor = true;
			this.btnThoat.Click += new System.EventHandler(this.btnThoat_Click);
			// 
			// btnXoaDo
			// 
			this.btnXoaDo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.btnXoaDo.Image = global::QuanLyTiemGiatLa.Properties.Resources.b_drop;
			this.btnXoaDo.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnXoaDo.Location = new System.Drawing.Point(666, 6);
			this.btnXoaDo.Name = "btnXoaDo";
			this.btnXoaDo.Size = new System.Drawing.Size(89, 58);
			this.btnXoaDo.TabIndex = 4;
			this.btnXoaDo.Text = "&Xóa";
			this.btnXoaDo.UseVisualStyleBackColor = true;
			this.btnXoaDo.Click += new System.EventHandler(this.btnXoaDo_Click);
			// 
			// btnThemDo
			// 
			this.btnThemDo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.btnThemDo.Image = global::QuanLyTiemGiatLa.Properties.Resources._11;
			this.btnThemDo.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnThemDo.Location = new System.Drawing.Point(570, 6);
			this.btnThemDo.Name = "btnThemDo";
			this.btnThemDo.Size = new System.Drawing.Size(90, 58);
			this.btnThemDo.TabIndex = 3;
			this.btnThemDo.Text = "Thê&m";
			this.btnThemDo.UseVisualStyleBackColor = true;
			this.btnThemDo.Click += new System.EventHandler(this.btnThemDo_Click);
			// 
			// label5
			// 
			this.label5.AutoSize = true;
			this.label5.Location = new System.Drawing.Point(328, 122);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(79, 20);
			this.label5.TabIndex = 11;
			this.label5.Text = "Tổng tiền:";
			// 
			// lblTongTien
			// 
			this.lblTongTien.AutoSize = true;
			this.lblTongTien.Font = new System.Drawing.Font("Courier New", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblTongTien.ForeColor = System.Drawing.Color.Red;
			this.lblTongTien.Location = new System.Drawing.Point(436, 124);
			this.lblTongTien.Name = "lblTongTien";
			this.lblTongTien.Size = new System.Drawing.Size(18, 18);
			this.lblTongTien.TabIndex = 9;
			this.lblTongTien.Text = "0";
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(563, 14);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(78, 20);
			this.label4.TabIndex = 13;
			this.label4.Text = "Mã phiếu:";
			// 
			// txtMaPhieu
			// 
			this.txtMaPhieu.Enabled = false;
			this.txtMaPhieu.Location = new System.Drawing.Point(666, 14);
			this.txtMaPhieu.Name = "txtMaPhieu";
			this.txtMaPhieu.Size = new System.Drawing.Size(183, 26);
			this.txtMaPhieu.TabIndex = 11;
			// 
			// label6
			// 
			this.label6.AutoSize = true;
			this.label6.Location = new System.Drawing.Point(328, 51);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(76, 20);
			this.label6.TabIndex = 13;
			this.label6.Text = "Giảm giá:";
			// 
			// nudGiamGia
			// 
			this.nudGiamGia.Enabled = false;
			this.nudGiamGia.Font = new System.Drawing.Font("Courier New", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.nudGiamGia.Location = new System.Drawing.Point(436, 47);
			this.nudGiamGia.Name = "nudGiamGia";
			this.nudGiamGia.Size = new System.Drawing.Size(60, 26);
			this.nudGiamGia.TabIndex = 6;
			this.nudGiamGia.ValueChanged += new System.EventHandler(this.nudGiamGia_ValueChanged);
			this.nudGiamGia.KeyDown += new System.Windows.Forms.KeyEventHandler(this.nudGiamGia_KeyDown);
			// 
			// label7
			// 
			this.label7.AutoSize = true;
			this.label7.Location = new System.Drawing.Point(13, 51);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(90, 20);
			this.label7.TabIndex = 15;
			this.label7.Text = "Loại khách:";
			// 
			// txtLoaiKhach
			// 
			this.txtLoaiKhach.Enabled = false;
			this.txtLoaiKhach.Location = new System.Drawing.Point(115, 47);
			this.txtLoaiKhach.Name = "txtLoaiKhach";
			this.txtLoaiKhach.Size = new System.Drawing.Size(164, 26);
			this.txtLoaiKhach.TabIndex = 2;
			// 
			// label8
			// 
			this.label8.AutoSize = true;
			this.label8.Location = new System.Drawing.Point(328, 17);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(88, 20);
			this.label8.TabIndex = 17;
			this.label8.Text = "Thành tiền:";
			// 
			// label9
			// 
			this.label9.AutoSize = true;
			this.label9.Location = new System.Drawing.Point(502, 51);
			this.label9.Name = "label9";
			this.label9.Size = new System.Drawing.Size(23, 20);
			this.label9.TabIndex = 17;
			this.label9.Text = "%";
			// 
			// lblThanhTien
			// 
			this.lblThanhTien.AutoSize = true;
			this.lblThanhTien.Font = new System.Drawing.Font("Courier New", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblThanhTien.Location = new System.Drawing.Point(436, 17);
			this.lblThanhTien.Name = "lblThanhTien";
			this.lblThanhTien.Size = new System.Drawing.Size(18, 18);
			this.lblThanhTien.TabIndex = 6;
			this.lblThanhTien.Text = "0";
			// 
			// label10
			// 
			this.label10.AutoSize = true;
			this.label10.Location = new System.Drawing.Point(13, 155);
			this.label10.Name = "label10";
			this.label10.Size = new System.Drawing.Size(68, 20);
			this.label10.TabIndex = 11;
			this.label10.Text = "Ghi chú:";
			// 
			// txtGhiChu
			// 
			this.txtGhiChu.Location = new System.Drawing.Point(115, 152);
			this.txtGhiChu.Name = "txtGhiChu";
			this.txtGhiChu.Size = new System.Drawing.Size(164, 26);
			this.txtGhiChu.TabIndex = 5;
			this.txtGhiChu.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtGhiChu_KeyDown);
			// 
			// label11
			// 
			this.label11.AutoSize = true;
			this.label11.Location = new System.Drawing.Point(328, 155);
			this.label11.Name = "label11";
			this.label11.Size = new System.Drawing.Size(80, 20);
			this.label11.TabIndex = 11;
			this.label11.Text = "KH đã trả:";
			// 
			// label12
			// 
			this.label12.AutoSize = true;
			this.label12.Location = new System.Drawing.Point(563, 155);
			this.label12.Name = "label12";
			this.label12.Size = new System.Drawing.Size(79, 20);
			this.label12.TabIndex = 11;
			this.label12.Text = "Tiền thừa:";
			// 
			// txtSoTienKHDaTra
			// 
			this.txtSoTienKHDaTra.Font = new System.Drawing.Font("Courier New", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txtSoTienKHDaTra.Location = new System.Drawing.Point(436, 149);
			this.txtSoTienKHDaTra.Name = "txtSoTienKHDaTra";
			this.txtSoTienKHDaTra.Size = new System.Drawing.Size(111, 26);
			this.txtSoTienKHDaTra.TabIndex = 8;
			this.txtSoTienKHDaTra.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.txtSoTienKHDaTra.TextChanged += new System.EventHandler(this.txtSoTienKHDaTra_TextChanged);
			this.txtSoTienKHDaTra.Enter += new System.EventHandler(this.txtSoTienKHDaTra_Enter);
			// 
			// lblTienTraLai
			// 
			this.lblTienTraLai.AutoSize = true;
			this.lblTienTraLai.Font = new System.Drawing.Font("Courier New", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblTienTraLai.ForeColor = System.Drawing.SystemColors.MenuHighlight;
			this.lblTienTraLai.Location = new System.Drawing.Point(648, 158);
			this.lblTienTraLai.Name = "lblTienTraLai";
			this.lblTienTraLai.Size = new System.Drawing.Size(18, 18);
			this.lblTienTraLai.TabIndex = 17;
			this.lblTienTraLai.Text = "0";
			// 
			// btnInHoaDon
			// 
			this.btnInHoaDon.Image = global::QuanLyTiemGiatLa.Properties.Resources.iCandy_Junior_02316;
			this.btnInHoaDon.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnInHoaDon.Location = new System.Drawing.Point(762, 83);
			this.btnInHoaDon.Name = "btnInHoaDon";
			this.btnInHoaDon.Size = new System.Drawing.Size(87, 58);
			this.btnInHoaDon.TabIndex = 10;
			this.btnInHoaDon.Text = "&In hóa đơn";
			this.btnInHoaDon.UseVisualStyleBackColor = true;
			this.btnInHoaDon.Click += new System.EventHandler(this.btnInHoaDon_Click);
			// 
			// btnGhi
			// 
			this.btnGhi.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.btnGhi.Image = global::QuanLyTiemGiatLa.Properties.Resources._45;
			this.btnGhi.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnGhi.Location = new System.Drawing.Point(284, 47);
			this.btnGhi.Name = "btnGhi";
			this.btnGhi.Size = new System.Drawing.Size(41, 58);
			this.btnGhi.TabIndex = 9;
			this.btnGhi.Text = "&Ghi";
			this.btnGhi.UseVisualStyleBackColor = true;
			this.btnGhi.Visible = false;
			this.btnGhi.Click += new System.EventHandler(this.btnGhi_Click);
			// 
			// btnFind
			// 
			this.btnFind.Image = global::QuanLyTiemGiatLa.Properties.Resources.find18;
			this.btnFind.Location = new System.Drawing.Point(284, 14);
			this.btnFind.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.btnFind.Name = "btnFind";
			this.btnFind.Size = new System.Drawing.Size(39, 26);
			this.btnFind.TabIndex = 1;
			this.btnFind.UseVisualStyleBackColor = true;
			this.btnFind.Click += new System.EventHandler(this.btnFind_Click);
			// 
			// dgvDSPhieuSlot
			// 
			this.dgvDSPhieuSlot.AllowUserToAddRows = false;
			this.dgvDSPhieuSlot.AllowUserToDeleteRows = false;
			this.dgvDSPhieuSlot.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
						| System.Windows.Forms.AnchorStyles.Left)
						| System.Windows.Forms.AnchorStyles.Right)));
			this.dgvDSPhieuSlot.AutoGenerateColumns = false;
			this.dgvDSPhieuSlot.BackgroundColor = System.Drawing.SystemColors.Control;
			this.dgvDSPhieuSlot.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dgvDSPhieuSlot.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.maPhieuDataGridViewTextBoxColumn1,
            this.sTTDataGridViewTextBoxColumn,
            this.maHangDataGridViewTextBoxColumn1,
            this.maKieuGiatDataGridViewTextBoxColumn1,
            this.maHienThiDataGridViewTextBoxColumn,
            this.MaVach,
            this.tenHangDataGridViewTextBoxColumn1,
            this.SoHieuSanPham,
            this.tenKieuGiatDataGridViewTextBoxColumn1,
            this.khoDataGridViewTextBoxColumn,
            this.slotDataGridViewTextBoxColumn,
            this.GhiChuSlot,
            this.daTraDataGridViewCheckBoxColumn,
            this.ThoiDiemLuu,
            this.NgayTraDataGridViewCheckBoxColumn});
			this.dgvDSPhieuSlot.DataSource = this.bndsrcDSPhieuSlot;
			this.dgvDSPhieuSlot.Location = new System.Drawing.Point(4, 467);
			this.dgvDSPhieuSlot.Name = "dgvDSPhieuSlot";
			this.dgvDSPhieuSlot.ReadOnly = true;
			this.dgvDSPhieuSlot.RowHeadersWidth = 20;
			this.dgvDSPhieuSlot.Size = new System.Drawing.Size(857, 183);
			this.dgvDSPhieuSlot.TabIndex = 20;
			// 
			// maPhieuDataGridViewTextBoxColumn1
			// 
			this.maPhieuDataGridViewTextBoxColumn1.DataPropertyName = "MaPhieu";
			this.maPhieuDataGridViewTextBoxColumn1.HeaderText = "MaPhieu";
			this.maPhieuDataGridViewTextBoxColumn1.Name = "maPhieuDataGridViewTextBoxColumn1";
			this.maPhieuDataGridViewTextBoxColumn1.ReadOnly = true;
			this.maPhieuDataGridViewTextBoxColumn1.Visible = false;
			// 
			// sTTDataGridViewTextBoxColumn
			// 
			this.sTTDataGridViewTextBoxColumn.DataPropertyName = "STT";
			this.sTTDataGridViewTextBoxColumn.HeaderText = "STT";
			this.sTTDataGridViewTextBoxColumn.Name = "sTTDataGridViewTextBoxColumn";
			this.sTTDataGridViewTextBoxColumn.ReadOnly = true;
			this.sTTDataGridViewTextBoxColumn.Visible = false;
			// 
			// maHangDataGridViewTextBoxColumn1
			// 
			this.maHangDataGridViewTextBoxColumn1.DataPropertyName = "MaHang";
			this.maHangDataGridViewTextBoxColumn1.HeaderText = "MaHang";
			this.maHangDataGridViewTextBoxColumn1.Name = "maHangDataGridViewTextBoxColumn1";
			this.maHangDataGridViewTextBoxColumn1.ReadOnly = true;
			this.maHangDataGridViewTextBoxColumn1.Visible = false;
			// 
			// maKieuGiatDataGridViewTextBoxColumn1
			// 
			this.maKieuGiatDataGridViewTextBoxColumn1.DataPropertyName = "MaKieuGiat";
			this.maKieuGiatDataGridViewTextBoxColumn1.HeaderText = "MaKieuGiat";
			this.maKieuGiatDataGridViewTextBoxColumn1.Name = "maKieuGiatDataGridViewTextBoxColumn1";
			this.maKieuGiatDataGridViewTextBoxColumn1.ReadOnly = true;
			this.maKieuGiatDataGridViewTextBoxColumn1.Visible = false;
			// 
			// maHienThiDataGridViewTextBoxColumn
			// 
			this.maHienThiDataGridViewTextBoxColumn.DataPropertyName = "MaHienThi";
			this.maHienThiDataGridViewTextBoxColumn.HeaderText = "Mã đồ";
			this.maHienThiDataGridViewTextBoxColumn.Name = "maHienThiDataGridViewTextBoxColumn";
			this.maHienThiDataGridViewTextBoxColumn.ReadOnly = true;
			this.maHienThiDataGridViewTextBoxColumn.Width = 90;
			// 
			// MaVach
			// 
			this.MaVach.DataPropertyName = "MaVach";
			this.MaVach.HeaderText = "Mã vạch";
			this.MaVach.Name = "MaVach";
			this.MaVach.ReadOnly = true;
			this.MaVach.Width = 95;
			// 
			// tenHangDataGridViewTextBoxColumn1
			// 
			this.tenHangDataGridViewTextBoxColumn1.DataPropertyName = "TenHang";
			this.tenHangDataGridViewTextBoxColumn1.HeaderText = "Tên đồ";
			this.tenHangDataGridViewTextBoxColumn1.Name = "tenHangDataGridViewTextBoxColumn1";
			this.tenHangDataGridViewTextBoxColumn1.ReadOnly = true;
			this.tenHangDataGridViewTextBoxColumn1.Width = 135;
			// 
			// SoHieuSanPham
			// 
			this.SoHieuSanPham.DataPropertyName = "SoHieuSanPham";
			this.SoHieuSanPham.HeaderText = "SHSP";
			this.SoHieuSanPham.Name = "SoHieuSanPham";
			this.SoHieuSanPham.ReadOnly = true;
			this.SoHieuSanPham.Width = 60;
			// 
			// tenKieuGiatDataGridViewTextBoxColumn1
			// 
			this.tenKieuGiatDataGridViewTextBoxColumn1.DataPropertyName = "TenKieuGiat";
			this.tenKieuGiatDataGridViewTextBoxColumn1.HeaderText = "Kiểu giặt";
			this.tenKieuGiatDataGridViewTextBoxColumn1.Name = "tenKieuGiatDataGridViewTextBoxColumn1";
			this.tenKieuGiatDataGridViewTextBoxColumn1.ReadOnly = true;
			this.tenKieuGiatDataGridViewTextBoxColumn1.Width = 95;
			// 
			// khoDataGridViewTextBoxColumn
			// 
			this.khoDataGridViewTextBoxColumn.DataPropertyName = "Kho";
			this.khoDataGridViewTextBoxColumn.HeaderText = "Kho";
			this.khoDataGridViewTextBoxColumn.Name = "khoDataGridViewTextBoxColumn";
			this.khoDataGridViewTextBoxColumn.ReadOnly = true;
			this.khoDataGridViewTextBoxColumn.Width = 50;
			// 
			// slotDataGridViewTextBoxColumn
			// 
			this.slotDataGridViewTextBoxColumn.DataPropertyName = "Slot";
			this.slotDataGridViewTextBoxColumn.HeaderText = "Slot";
			this.slotDataGridViewTextBoxColumn.Name = "slotDataGridViewTextBoxColumn";
			this.slotDataGridViewTextBoxColumn.ReadOnly = true;
			this.slotDataGridViewTextBoxColumn.Width = 50;
			// 
			// GhiChuSlot
			// 
			this.GhiChuSlot.DataPropertyName = "GhiChu";
			this.GhiChuSlot.HeaderText = "Ghi chú";
			this.GhiChuSlot.Name = "GhiChuSlot";
			this.GhiChuSlot.ReadOnly = true;
			this.GhiChuSlot.Width = 120;
			// 
			// daTraDataGridViewCheckBoxColumn
			// 
			this.daTraDataGridViewCheckBoxColumn.DataPropertyName = "DaTra";
			this.daTraDataGridViewCheckBoxColumn.HeaderText = "Đã trả";
			this.daTraDataGridViewCheckBoxColumn.Name = "daTraDataGridViewCheckBoxColumn";
			this.daTraDataGridViewCheckBoxColumn.ReadOnly = true;
			this.daTraDataGridViewCheckBoxColumn.Width = 60;
			// 
			// ThoiDiemLuu
			// 
			this.ThoiDiemLuu.DataPropertyName = "ThoiDiemLuu";
			this.ThoiDiemLuu.HeaderText = "Tg lưu";
			this.ThoiDiemLuu.Name = "ThoiDiemLuu";
			this.ThoiDiemLuu.ReadOnly = true;
			// 
			// NgayTraDataGridViewCheckBoxColumn
			// 
			this.NgayTraDataGridViewCheckBoxColumn.DataPropertyName = "NgayTra";
			this.NgayTraDataGridViewCheckBoxColumn.HeaderText = "Ngày trả";
			this.NgayTraDataGridViewCheckBoxColumn.Name = "NgayTraDataGridViewCheckBoxColumn";
			this.NgayTraDataGridViewCheckBoxColumn.ReadOnly = true;
			// 
			// bndsrcDSPhieuSlot
			// 
			this.bndsrcDSPhieuSlot.DataSource = typeof(Entity.ListPhieuSlotEntity);
			// 
			// chkDaThanhToan
			// 
			this.chkDaThanhToan.AutoSize = true;
			this.chkDaThanhToan.Checked = true;
			this.chkDaThanhToan.CheckState = System.Windows.Forms.CheckState.Checked;
			this.chkDaThanhToan.Location = new System.Drawing.Point(567, 47);
			this.chkDaThanhToan.Name = "chkDaThanhToan";
			this.chkDaThanhToan.Size = new System.Drawing.Size(130, 24);
			this.chkDaThanhToan.TabIndex = 9;
			this.chkDaThanhToan.Text = "Đã thanh toán";
			this.chkDaThanhToan.UseVisualStyleBackColor = true;
			// 
			// label13
			// 
			this.label13.AutoSize = true;
			this.label13.Location = new System.Drawing.Point(563, 87);
			this.label13.Name = "label13";
			this.label13.Size = new System.Drawing.Size(103, 20);
			this.label13.TabIndex = 13;
			this.label13.Text = "Mã vạch đầu:";
			// 
			// txtMaVachDauTien
			// 
			this.txtMaVachDauTien.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txtMaVachDauTien.Location = new System.Drawing.Point(666, 83);
			this.txtMaVachDauTien.Name = "txtMaVachDauTien";
			this.txtMaVachDauTien.ReadOnly = true;
			this.txtMaVachDauTien.Size = new System.Drawing.Size(90, 26);
			this.txtMaVachDauTien.TabIndex = 14;
			// 
			// label16
			// 
			this.label16.AutoSize = true;
			this.label16.Location = new System.Drawing.Point(563, 122);
			this.label16.Name = "label16";
			this.label16.Size = new System.Drawing.Size(105, 20);
			this.label16.TabIndex = 13;
			this.label16.Text = "Mã vạch cuối:";
			// 
			// txtMaVachCuoi
			// 
			this.txtMaVachCuoi.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txtMaVachCuoi.Location = new System.Drawing.Point(666, 119);
			this.txtMaVachCuoi.Name = "txtMaVachCuoi";
			this.txtMaVachCuoi.ReadOnly = true;
			this.txtMaVachCuoi.Size = new System.Drawing.Size(90, 26);
			this.txtMaVachCuoi.TabIndex = 15;
			// 
			// chkPhiGiaoNhan
			// 
			this.chkPhiGiaoNhan.AutoSize = true;
			this.chkPhiGiaoNhan.Location = new System.Drawing.Point(332, 85);
			this.chkPhiGiaoNhan.Name = "chkPhiGiaoNhan";
			this.chkPhiGiaoNhan.Size = new System.Drawing.Size(124, 24);
			this.chkPhiGiaoNhan.TabIndex = 7;
			this.chkPhiGiaoNhan.Text = "Phí giao nhận";
			this.chkPhiGiaoNhan.UseVisualStyleBackColor = true;
			this.chkPhiGiaoNhan.CheckedChanged += new System.EventHandler(this.chkPhiGiaoNhan_CheckedChanged);
			this.chkPhiGiaoNhan.KeyDown += new System.Windows.Forms.KeyEventHandler(this.chkPhiGiaoNhan_KeyDown);
			// 
			// frmLapPhieu
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.CancelButton = this.btnThoat;
			this.ClientSize = new System.Drawing.Size(864, 652);
			this.Controls.Add(this.chkPhiGiaoNhan);
			this.Controls.Add(this.dgvDSPhieuSlot);
			this.Controls.Add(this.txtSoTienKHDaTra);
			this.Controls.Add(this.chkDaThanhToan);
			this.Controls.Add(this.btnInHoaDon);
			this.Controls.Add(this.txtGhiChu);
			this.Controls.Add(this.label9);
			this.Controls.Add(this.txtMaVachCuoi);
			this.Controls.Add(this.txtMaVachDauTien);
			this.Controls.Add(this.label8);
			this.Controls.Add(this.txtLoaiKhach);
			this.Controls.Add(this.label7);
			this.Controls.Add(this.nudGiamGia);
			this.Controls.Add(this.label6);
			this.Controls.Add(this.txtMaPhieu);
			this.Controls.Add(this.lblThanhTien);
			this.Controls.Add(this.lblTienTraLai);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.lblTongTien);
			this.Controls.Add(this.label12);
			this.Controls.Add(this.label11);
			this.Controls.Add(this.label10);
			this.Controls.Add(this.label5);
			this.Controls.Add(this.label16);
			this.Controls.Add(this.label13);
			this.Controls.Add(this.panel1);
			this.Controls.Add(this.dgvDSDo);
			this.Controls.Add(this.dtpNgayHenTra);
			this.Controls.Add(this.dtpNgayLap);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.btnGhi);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.btnFind);
			this.Controls.Add(this.txtTenKhachHang);
			this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.Name = "frmLapPhieu";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Lập phiếu";
			this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmLapPhieu_FormClosing);
			((System.ComponentModel.ISupportInitialize)(this.dgvDSDo)).EndInit();
			this.contextMenuStrip1.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.bndsrcDSCTPhieu)).EndInit();
			this.panel1.ResumeLayout(false);
			this.panel1.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.nudGiamGia)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.dgvDSPhieuSlot)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.bndsrcDSPhieuSlot)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Button btnFind;
		private System.Windows.Forms.TextBox txtTenKhachHang;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Button btnThemDo;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Button btnThoat;
		private System.Windows.Forms.Button btnGhi;
		private System.Windows.Forms.DateTimePicker dtpNgayLap;
		private System.Windows.Forms.DateTimePicker dtpNgayHenTra;
		private System.Windows.Forms.DataGridView dgvDSDo;
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label lblTongTien;
		private System.Windows.Forms.Button btnXoaDo;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.TextBox txtMaPhieu;
		private System.Windows.Forms.BindingSource bndsrcDSCTPhieu;
		private System.Windows.Forms.Button btnInHoaDon;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.NumericUpDown nudGiamGia;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.TextBox txtLoaiKhach;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.Label label9;
		private System.Windows.Forms.Label lblThanhTien;
		private System.Windows.Forms.Label label10;
		private System.Windows.Forms.TextBox txtGhiChu;
		private System.Windows.Forms.Label label11;
		private System.Windows.Forms.Label label12;
		private System.Windows.Forms.TextBox txtSoTienKHDaTra;
		private System.Windows.Forms.Label lblTienTraLai;
		private System.Windows.Forms.Button btnCatDo;
		private System.Windows.Forms.TextBox txtUserName;
		private System.Windows.Forms.DataGridView dgvDSPhieuSlot;
		private System.Windows.Forms.BindingSource bndsrcDSPhieuSlot;
		private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
		private System.Windows.Forms.ToolStripMenuItem mnuXoa;
		private System.Windows.Forms.CheckBox chkDaThanhToan;
		private System.Windows.Forms.Label label13;
		private System.Windows.Forms.TextBox txtMaVachDauTien;
		private System.Windows.Forms.Label label15;
		private System.Windows.Forms.Label label14;
		private System.Windows.Forms.TextBox txtTongSoSanPham;
        private System.Windows.Forms.Label label16;
		private System.Windows.Forms.TextBox txtMaVachCuoi;
		private System.Windows.Forms.DataGridViewTextBoxColumn iDChiTietPhieuDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn maPhieuDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn maHangDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn maKieuGiatDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn tenHangDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn tenKieuGiatDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn soluongDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn donGiaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn GhiChu;
        private System.Windows.Forms.DataGridViewTextBoxColumn maPhieuDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn sTTDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn maHangDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn maKieuGiatDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn maHienThiDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaVach;
        private System.Windows.Forms.DataGridViewTextBoxColumn tenHangDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn SoHieuSanPham;
        private System.Windows.Forms.DataGridViewTextBoxColumn tenKieuGiatDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn khoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn slotDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn GhiChuSlot;
        private System.Windows.Forms.DataGridViewCheckBoxColumn daTraDataGridViewCheckBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn ThoiDiemLuu;
        private System.Windows.Forms.DataGridViewTextBoxColumn NgayTraDataGridViewCheckBoxColumn;
		private System.Windows.Forms.CheckBox chkPhiGiaoNhan;
	}
}