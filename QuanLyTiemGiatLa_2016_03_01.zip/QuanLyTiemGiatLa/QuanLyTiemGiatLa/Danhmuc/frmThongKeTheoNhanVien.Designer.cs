﻿namespace QuanLyTiemGiatLa.Danhmuc
{
	partial class frmThongKeTheoNhanVien
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmThongKeTheoNhanVien));
			this.splitContainer1 = new System.Windows.Forms.SplitContainer();
			this.txtTongCong = new System.Windows.Forms.TextBox();
			this.btnSearch = new System.Windows.Forms.Button();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.dtpDenNgay = new System.Windows.Forms.DateTimePicker();
			this.dtpTuNgay = new System.Windows.Forms.DateTimePicker();
			this.label2 = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.splitContainer2 = new System.Windows.Forms.SplitContainer();
			this.dgvDSNhanVien = new System.Windows.Forms.DataGridView();
			this.passwordDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.quyenDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.quyenHanDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.userNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.hoTenDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.bndsrcDSNhanVien = new System.Windows.Forms.BindingSource(this.components);
			this.dgvDSPhieu = new System.Windows.Forms.DataGridView();
			this.maKhachHangDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.ngayLapDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.ngayHenTraDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.daTraDoDataGridViewCheckBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
			this.userNameDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.maPhieuDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.tenKhachHangDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.giamGiaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.TongTien = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.daThanhToanDataGridViewCheckBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
			this.ghiChuDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.bndsrcDSPhieu = new System.Windows.Forms.BindingSource(this.components);
			this.panel1 = new System.Windows.Forms.Panel();
			this.btnThoat = new System.Windows.Forms.Button();
			this.btnCollapse = new System.Windows.Forms.Button();
			this.splitContainer1.Panel1.SuspendLayout();
			this.splitContainer1.Panel2.SuspendLayout();
			this.splitContainer1.SuspendLayout();
			this.groupBox1.SuspendLayout();
			this.splitContainer2.Panel1.SuspendLayout();
			this.splitContainer2.Panel2.SuspendLayout();
			this.splitContainer2.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.dgvDSNhanVien)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.bndsrcDSNhanVien)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.dgvDSPhieu)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.bndsrcDSPhieu)).BeginInit();
			this.panel1.SuspendLayout();
			this.SuspendLayout();
			// 
			// splitContainer1
			// 
			this.splitContainer1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.splitContainer1.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
			this.splitContainer1.Location = new System.Drawing.Point(0, 0);
			this.splitContainer1.Name = "splitContainer1";
			// 
			// splitContainer1.Panel1
			// 
			this.splitContainer1.Panel1.Controls.Add(this.txtTongCong);
			this.splitContainer1.Panel1.Controls.Add(this.btnSearch);
			this.splitContainer1.Panel1.Controls.Add(this.groupBox1);
			this.splitContainer1.Panel1.Controls.Add(this.label3);
			// 
			// splitContainer1.Panel2
			// 
			this.splitContainer1.Panel2.Controls.Add(this.splitContainer2);
			this.splitContainer1.Panel2.Controls.Add(this.panel1);
			this.splitContainer1.Size = new System.Drawing.Size(887, 612);
			this.splitContainer1.SplitterDistance = 151;
			this.splitContainer1.TabIndex = 1;
			// 
			// txtTongCong
			// 
			this.txtTongCong.BackColor = System.Drawing.SystemColors.Control;
			this.txtTongCong.ForeColor = System.Drawing.Color.Red;
			this.txtTongCong.Location = new System.Drawing.Point(10, 265);
			this.txtTongCong.Name = "txtTongCong";
			this.txtTongCong.ReadOnly = true;
			this.txtTongCong.Size = new System.Drawing.Size(127, 26);
			this.txtTongCong.TabIndex = 2;
			this.txtTongCong.Text = "0";
			this.txtTongCong.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			// 
			// btnSearch
			// 
			this.btnSearch.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.btnSearch.Image = global::QuanLyTiemGiatLa.Properties.Resources._49;
			this.btnSearch.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnSearch.Location = new System.Drawing.Point(55, 167);
			this.btnSearch.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.btnSearch.Name = "btnSearch";
			this.btnSearch.Size = new System.Drawing.Size(92, 53);
			this.btnSearch.TabIndex = 1;
			this.btnSearch.Text = "Tì&m";
			this.btnSearch.UseVisualStyleBackColor = true;
			this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
			// 
			// groupBox1
			// 
			this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
						| System.Windows.Forms.AnchorStyles.Right)));
			this.groupBox1.Controls.Add(this.dtpDenNgay);
			this.groupBox1.Controls.Add(this.dtpTuNgay);
			this.groupBox1.Controls.Add(this.label2);
			this.groupBox1.Controls.Add(this.label1);
			this.groupBox1.Location = new System.Drawing.Point(4, 4);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(143, 158);
			this.groupBox1.TabIndex = 0;
			this.groupBox1.TabStop = false;
			// 
			// dtpDenNgay
			// 
			this.dtpDenNgay.CustomFormat = "dd/MM/yyyy";
			this.dtpDenNgay.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			this.dtpDenNgay.Location = new System.Drawing.Point(6, 111);
			this.dtpDenNgay.Name = "dtpDenNgay";
			this.dtpDenNgay.Size = new System.Drawing.Size(127, 26);
			this.dtpDenNgay.TabIndex = 1;
			// 
			// dtpTuNgay
			// 
			this.dtpTuNgay.CustomFormat = "dd/MM/yyyy";
			this.dtpTuNgay.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			this.dtpTuNgay.Location = new System.Drawing.Point(6, 47);
			this.dtpTuNgay.Name = "dtpTuNgay";
			this.dtpTuNgay.Size = new System.Drawing.Size(127, 26);
			this.dtpTuNgay.TabIndex = 0;
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(2, 82);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(81, 20);
			this.label2.TabIndex = 0;
			this.label2.Text = "Đến ngày:";
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(2, 18);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(69, 20);
			this.label1.TabIndex = 0;
			this.label1.Text = "Từ ngày:";
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(6, 233);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(88, 20);
			this.label3.TabIndex = 0;
			this.label3.Text = "Tổng cộng:";
			// 
			// splitContainer2
			// 
			this.splitContainer2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.splitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
			this.splitContainer2.Location = new System.Drawing.Point(0, 0);
			this.splitContainer2.Name = "splitContainer2";
			this.splitContainer2.Orientation = System.Windows.Forms.Orientation.Horizontal;
			// 
			// splitContainer2.Panel1
			// 
			this.splitContainer2.Panel1.Controls.Add(this.dgvDSNhanVien);
			// 
			// splitContainer2.Panel2
			// 
			this.splitContainer2.Panel2.Controls.Add(this.dgvDSPhieu);
			this.splitContainer2.Size = new System.Drawing.Size(732, 543);
			this.splitContainer2.SplitterDistance = 200;
			this.splitContainer2.TabIndex = 1;
			// 
			// dgvDSNhanVien
			// 
			this.dgvDSNhanVien.AllowUserToAddRows = false;
			this.dgvDSNhanVien.AllowUserToDeleteRows = false;
			this.dgvDSNhanVien.AutoGenerateColumns = false;
			this.dgvDSNhanVien.BackgroundColor = System.Drawing.SystemColors.Control;
			this.dgvDSNhanVien.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dgvDSNhanVien.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.passwordDataGridViewTextBoxColumn,
            this.quyenDataGridViewTextBoxColumn,
            this.quyenHanDataGridViewTextBoxColumn,
            this.userNameDataGridViewTextBoxColumn,
            this.hoTenDataGridViewTextBoxColumn});
			this.dgvDSNhanVien.DataSource = this.bndsrcDSNhanVien;
			this.dgvDSNhanVien.Dock = System.Windows.Forms.DockStyle.Fill;
			this.dgvDSNhanVien.Location = new System.Drawing.Point(0, 0);
			this.dgvDSNhanVien.Name = "dgvDSNhanVien";
			this.dgvDSNhanVien.ReadOnly = true;
			this.dgvDSNhanVien.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
			this.dgvDSNhanVien.Size = new System.Drawing.Size(728, 196);
			this.dgvDSNhanVien.TabIndex = 0;
			// 
			// passwordDataGridViewTextBoxColumn
			// 
			this.passwordDataGridViewTextBoxColumn.DataPropertyName = "Password";
			this.passwordDataGridViewTextBoxColumn.HeaderText = "Tài khoản";
			this.passwordDataGridViewTextBoxColumn.Name = "passwordDataGridViewTextBoxColumn";
			this.passwordDataGridViewTextBoxColumn.ReadOnly = true;
			this.passwordDataGridViewTextBoxColumn.Visible = false;
			// 
			// quyenDataGridViewTextBoxColumn
			// 
			this.quyenDataGridViewTextBoxColumn.DataPropertyName = "Quyen";
			this.quyenDataGridViewTextBoxColumn.HeaderText = "Quyen";
			this.quyenDataGridViewTextBoxColumn.Name = "quyenDataGridViewTextBoxColumn";
			this.quyenDataGridViewTextBoxColumn.ReadOnly = true;
			this.quyenDataGridViewTextBoxColumn.Visible = false;
			// 
			// quyenHanDataGridViewTextBoxColumn
			// 
			this.quyenHanDataGridViewTextBoxColumn.DataPropertyName = "QuyenHan";
			this.quyenHanDataGridViewTextBoxColumn.HeaderText = "QuyenHan";
			this.quyenHanDataGridViewTextBoxColumn.Name = "quyenHanDataGridViewTextBoxColumn";
			this.quyenHanDataGridViewTextBoxColumn.ReadOnly = true;
			this.quyenHanDataGridViewTextBoxColumn.Visible = false;
			// 
			// userNameDataGridViewTextBoxColumn
			// 
			this.userNameDataGridViewTextBoxColumn.DataPropertyName = "UserName";
			this.userNameDataGridViewTextBoxColumn.HeaderText = "UserName";
			this.userNameDataGridViewTextBoxColumn.Name = "userNameDataGridViewTextBoxColumn";
			this.userNameDataGridViewTextBoxColumn.ReadOnly = true;
			this.userNameDataGridViewTextBoxColumn.Width = 200;
			// 
			// hoTenDataGridViewTextBoxColumn
			// 
			this.hoTenDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
			this.hoTenDataGridViewTextBoxColumn.DataPropertyName = "HoTen";
			this.hoTenDataGridViewTextBoxColumn.HeaderText = "Họ tên";
			this.hoTenDataGridViewTextBoxColumn.Name = "hoTenDataGridViewTextBoxColumn";
			this.hoTenDataGridViewTextBoxColumn.ReadOnly = true;
			// 
			// bndsrcDSNhanVien
			// 
			this.bndsrcDSNhanVien.DataSource = typeof(Entity.ListUserEntity);
			this.bndsrcDSNhanVien.CurrentChanged += new System.EventHandler(this.bndsrcDSNhanVien_CurrentChanged);
			// 
			// dgvDSPhieu
			// 
			this.dgvDSPhieu.AllowUserToAddRows = false;
			this.dgvDSPhieu.AllowUserToDeleteRows = false;
			this.dgvDSPhieu.AutoGenerateColumns = false;
			this.dgvDSPhieu.BackgroundColor = System.Drawing.SystemColors.Control;
			this.dgvDSPhieu.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dgvDSPhieu.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.maKhachHangDataGridViewTextBoxColumn,
            this.ngayLapDataGridViewTextBoxColumn,
            this.ngayHenTraDataGridViewTextBoxColumn,
            this.daTraDoDataGridViewCheckBoxColumn,
            this.userNameDataGridViewTextBoxColumn1,
            this.maPhieuDataGridViewTextBoxColumn,
            this.tenKhachHangDataGridViewTextBoxColumn,
            this.giamGiaDataGridViewTextBoxColumn,
            this.TongTien,
            this.daThanhToanDataGridViewCheckBoxColumn,
            this.ghiChuDataGridViewTextBoxColumn});
			this.dgvDSPhieu.DataSource = this.bndsrcDSPhieu;
			this.dgvDSPhieu.Dock = System.Windows.Forms.DockStyle.Fill;
			this.dgvDSPhieu.Location = new System.Drawing.Point(0, 0);
			this.dgvDSPhieu.Name = "dgvDSPhieu";
			this.dgvDSPhieu.ReadOnly = true;
			this.dgvDSPhieu.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
			this.dgvDSPhieu.Size = new System.Drawing.Size(728, 335);
			this.dgvDSPhieu.TabIndex = 0;
			// 
			// maKhachHangDataGridViewTextBoxColumn
			// 
			this.maKhachHangDataGridViewTextBoxColumn.DataPropertyName = "MaKhachHang";
			this.maKhachHangDataGridViewTextBoxColumn.HeaderText = "MaKhachHang";
			this.maKhachHangDataGridViewTextBoxColumn.Name = "maKhachHangDataGridViewTextBoxColumn";
			this.maKhachHangDataGridViewTextBoxColumn.ReadOnly = true;
			this.maKhachHangDataGridViewTextBoxColumn.Visible = false;
			// 
			// ngayLapDataGridViewTextBoxColumn
			// 
			this.ngayLapDataGridViewTextBoxColumn.DataPropertyName = "NgayLap";
			this.ngayLapDataGridViewTextBoxColumn.HeaderText = "Ngaylap";
			this.ngayLapDataGridViewTextBoxColumn.Name = "ngayLapDataGridViewTextBoxColumn";
			this.ngayLapDataGridViewTextBoxColumn.ReadOnly = true;
			this.ngayLapDataGridViewTextBoxColumn.Visible = false;
			// 
			// ngayHenTraDataGridViewTextBoxColumn
			// 
			this.ngayHenTraDataGridViewTextBoxColumn.DataPropertyName = "NgayHenTra";
			this.ngayHenTraDataGridViewTextBoxColumn.HeaderText = "NgayHenTra";
			this.ngayHenTraDataGridViewTextBoxColumn.Name = "ngayHenTraDataGridViewTextBoxColumn";
			this.ngayHenTraDataGridViewTextBoxColumn.ReadOnly = true;
			this.ngayHenTraDataGridViewTextBoxColumn.Visible = false;
			// 
			// daTraDoDataGridViewCheckBoxColumn
			// 
			this.daTraDoDataGridViewCheckBoxColumn.DataPropertyName = "DaTraDo";
			this.daTraDoDataGridViewCheckBoxColumn.HeaderText = "DaTraDo";
			this.daTraDoDataGridViewCheckBoxColumn.Name = "daTraDoDataGridViewCheckBoxColumn";
			this.daTraDoDataGridViewCheckBoxColumn.ReadOnly = true;
			this.daTraDoDataGridViewCheckBoxColumn.Visible = false;
			// 
			// userNameDataGridViewTextBoxColumn1
			// 
			this.userNameDataGridViewTextBoxColumn1.DataPropertyName = "UserName";
			this.userNameDataGridViewTextBoxColumn1.HeaderText = "UserName";
			this.userNameDataGridViewTextBoxColumn1.Name = "userNameDataGridViewTextBoxColumn1";
			this.userNameDataGridViewTextBoxColumn1.ReadOnly = true;
			this.userNameDataGridViewTextBoxColumn1.Visible = false;
			// 
			// maPhieuDataGridViewTextBoxColumn
			// 
			this.maPhieuDataGridViewTextBoxColumn.DataPropertyName = "MaPhieu";
			this.maPhieuDataGridViewTextBoxColumn.HeaderText = "Mã phiếu";
			this.maPhieuDataGridViewTextBoxColumn.Name = "maPhieuDataGridViewTextBoxColumn";
			this.maPhieuDataGridViewTextBoxColumn.ReadOnly = true;
			// 
			// tenKhachHangDataGridViewTextBoxColumn
			// 
			this.tenKhachHangDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
			this.tenKhachHangDataGridViewTextBoxColumn.DataPropertyName = "TenKhachHang";
			this.tenKhachHangDataGridViewTextBoxColumn.HeaderText = "Khách hàng";
			this.tenKhachHangDataGridViewTextBoxColumn.Name = "tenKhachHangDataGridViewTextBoxColumn";
			this.tenKhachHangDataGridViewTextBoxColumn.ReadOnly = true;
			// 
			// giamGiaDataGridViewTextBoxColumn
			// 
			this.giamGiaDataGridViewTextBoxColumn.DataPropertyName = "GiamGia";
			dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
			this.giamGiaDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle1;
			this.giamGiaDataGridViewTextBoxColumn.HeaderText = "Giảm giá (%)";
			this.giamGiaDataGridViewTextBoxColumn.Name = "giamGiaDataGridViewTextBoxColumn";
			this.giamGiaDataGridViewTextBoxColumn.ReadOnly = true;
			this.giamGiaDataGridViewTextBoxColumn.Width = 70;
			// 
			// TongTien
			// 
			this.TongTien.DataPropertyName = "TongTien";
			dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Red;
			dataGridViewCellStyle2.Format = "N0";
			this.TongTien.DefaultCellStyle = dataGridViewCellStyle2;
			this.TongTien.HeaderText = "Tổng tiền (đã giảm)";
			this.TongTien.Name = "TongTien";
			this.TongTien.ReadOnly = true;
			this.TongTien.Width = 120;
			// 
			// daThanhToanDataGridViewCheckBoxColumn
			// 
			this.daThanhToanDataGridViewCheckBoxColumn.DataPropertyName = "DaThanhToan";
			this.daThanhToanDataGridViewCheckBoxColumn.HeaderText = "Đã thanh toán";
			this.daThanhToanDataGridViewCheckBoxColumn.Name = "daThanhToanDataGridViewCheckBoxColumn";
			this.daThanhToanDataGridViewCheckBoxColumn.ReadOnly = true;
			this.daThanhToanDataGridViewCheckBoxColumn.Width = 60;
			// 
			// ghiChuDataGridViewTextBoxColumn
			// 
			this.ghiChuDataGridViewTextBoxColumn.DataPropertyName = "GhiChu";
			this.ghiChuDataGridViewTextBoxColumn.HeaderText = "GhiChu";
			this.ghiChuDataGridViewTextBoxColumn.Name = "ghiChuDataGridViewTextBoxColumn";
			this.ghiChuDataGridViewTextBoxColumn.ReadOnly = true;
			this.ghiChuDataGridViewTextBoxColumn.Width = 120;
			// 
			// bndsrcDSPhieu
			// 
			this.bndsrcDSPhieu.DataSource = typeof(Entity.ListPhieuEntity);
			// 
			// panel1
			// 
			this.panel1.Controls.Add(this.btnThoat);
			this.panel1.Controls.Add(this.btnCollapse);
			this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.panel1.Location = new System.Drawing.Point(0, 543);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(732, 69);
			this.panel1.TabIndex = 0;
			// 
			// btnThoat
			// 
			this.btnThoat.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.btnThoat.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.btnThoat.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnThoat.Image = global::QuanLyTiemGiatLa.Properties.Resources.Exit16;
			this.btnThoat.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnThoat.Location = new System.Drawing.Point(636, 7);
			this.btnThoat.Margin = new System.Windows.Forms.Padding(4);
			this.btnThoat.Name = "btnThoat";
			this.btnThoat.Size = new System.Drawing.Size(91, 53);
			this.btnThoat.TabIndex = 1;
			this.btnThoat.Text = "&Thoát";
			this.btnThoat.UseVisualStyleBackColor = true;
			this.btnThoat.Click += new System.EventHandler(this.btnThoat_Click);
			// 
			// btnCollapse
			// 
			this.btnCollapse.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.btnCollapse.Location = new System.Drawing.Point(3, 7);
			this.btnCollapse.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.btnCollapse.Name = "btnCollapse";
			this.btnCollapse.Size = new System.Drawing.Size(60, 53);
			this.btnCollapse.TabIndex = 0;
			this.btnCollapse.Text = "<<";
			this.btnCollapse.UseVisualStyleBackColor = true;
			this.btnCollapse.Click += new System.EventHandler(this.btnCollapse_Click);
			// 
			// frmThongKeTheoNhanVien
			// 
			this.AcceptButton = this.btnSearch;
			this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.CancelButton = this.btnThoat;
			this.ClientSize = new System.Drawing.Size(887, 612);
			this.Controls.Add(this.splitContainer1);
			this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.Name = "frmThongKeTheoNhanVien";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Thống kê theo nhân viên";
			this.splitContainer1.Panel1.ResumeLayout(false);
			this.splitContainer1.Panel1.PerformLayout();
			this.splitContainer1.Panel2.ResumeLayout(false);
			this.splitContainer1.ResumeLayout(false);
			this.groupBox1.ResumeLayout(false);
			this.groupBox1.PerformLayout();
			this.splitContainer2.Panel1.ResumeLayout(false);
			this.splitContainer2.Panel2.ResumeLayout(false);
			this.splitContainer2.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.dgvDSNhanVien)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.bndsrcDSNhanVien)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.dgvDSPhieu)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.bndsrcDSPhieu)).EndInit();
			this.panel1.ResumeLayout(false);
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.SplitContainer splitContainer1;
		private System.Windows.Forms.TextBox txtTongCong;
		private System.Windows.Forms.Button btnSearch;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.DateTimePicker dtpDenNgay;
		private System.Windows.Forms.DateTimePicker dtpTuNgay;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.SplitContainer splitContainer2;
		private System.Windows.Forms.DataGridView dgvDSNhanVien;
		private System.Windows.Forms.DataGridView dgvDSPhieu;
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.Button btnThoat;
		private System.Windows.Forms.Button btnCollapse;
		private System.Windows.Forms.DataGridViewTextBoxColumn passwordDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn quyenDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn quyenHanDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn userNameDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn hoTenDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn tenQuyenDataGridViewTextBoxColumn;
		private System.Windows.Forms.BindingSource bndsrcDSNhanVien;
		private System.Windows.Forms.BindingSource bndsrcDSPhieu;
		private System.Windows.Forms.DataGridViewTextBoxColumn maKhachHangDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn ngayLapDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn ngayHenTraDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewCheckBoxColumn daTraDoDataGridViewCheckBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn userNameDataGridViewTextBoxColumn1;
		private System.Windows.Forms.DataGridViewTextBoxColumn maPhieuDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn tenKhachHangDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn giamGiaDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn TongTien;
		private System.Windows.Forms.DataGridViewCheckBoxColumn daThanhToanDataGridViewCheckBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn ghiChuDataGridViewTextBoxColumn;
	}
}