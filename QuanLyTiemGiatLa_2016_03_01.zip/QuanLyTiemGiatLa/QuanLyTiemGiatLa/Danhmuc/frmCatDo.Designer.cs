﻿namespace QuanLyTiemGiatLa.Danhmuc
{
	partial class frmCatDo
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmCatDo));
			this.splitContainer1 = new System.Windows.Forms.SplitContainer();
			this.chkPhieuChuaTra = new System.Windows.Forms.CheckBox();
			this.chkTimTheoNgay = new System.Windows.Forms.CheckBox();
			this.lblDenNgay = new System.Windows.Forms.Label();
			this.lblTuNgay = new System.Windows.Forms.Label();
			this.dtpDenNgay = new System.Windows.Forms.DateTimePicker();
			this.dtpTuNgay = new System.Windows.Forms.DateTimePicker();
			this.btnSearch = new System.Windows.Forms.Button();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.txtTenDo = new System.Windows.Forms.TextBox();
			this.label6 = new System.Windows.Forms.Label();
			this.txtMaVach = new System.Windows.Forms.TextBox();
			this.txtMaPhieu = new System.Windows.Forms.TextBox();
			this.label4 = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.dgvDSCatDo = new System.Windows.Forms.DataGridView();
			this.maPhieuDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.sTTDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.maHangDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.maKieuGiatDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.maHienThiDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.maVachDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.tenHangDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.SoHieuSanPham = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.tenKieuGiatDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.khoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.slotDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.daTraDataGridViewCheckBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
			this.ghichuDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.ThoiDiemLuu = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.NgayTraDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.bndsrcDSCatDo = new System.Windows.Forms.BindingSource(this.components);
			this.panel1 = new System.Windows.Forms.Panel();
			this.txtSoDienThoai = new System.Windows.Forms.TextBox();
			this.label3 = new System.Windows.Forms.Label();
			this.txtTenKhachHang = new System.Windows.Forms.TextBox();
			this.label2 = new System.Windows.Forms.Label();
			this.btnThoat = new System.Windows.Forms.Button();
			this.btnGhi = new System.Windows.Forms.Button();
			this.btnXemKhachHang = new System.Windows.Forms.Button();
			this.btnXemPhieu = new System.Windows.Forms.Button();
			this.btnCollapse = new System.Windows.Forms.Button();
			this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
			this.ghiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.xemPhieuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.xemKhachHangToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.splitContainer1.Panel1.SuspendLayout();
			this.splitContainer1.Panel2.SuspendLayout();
			this.splitContainer1.SuspendLayout();
			this.groupBox1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.dgvDSCatDo)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.bndsrcDSCatDo)).BeginInit();
			this.panel1.SuspendLayout();
			this.contextMenuStrip1.SuspendLayout();
			this.SuspendLayout();
			// 
			// splitContainer1
			// 
			this.splitContainer1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.splitContainer1.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
			this.splitContainer1.Location = new System.Drawing.Point(0, 0);
			this.splitContainer1.Name = "splitContainer1";
			// 
			// splitContainer1.Panel1
			// 
			this.splitContainer1.Panel1.Controls.Add(this.chkPhieuChuaTra);
			this.splitContainer1.Panel1.Controls.Add(this.chkTimTheoNgay);
			this.splitContainer1.Panel1.Controls.Add(this.lblDenNgay);
			this.splitContainer1.Panel1.Controls.Add(this.lblTuNgay);
			this.splitContainer1.Panel1.Controls.Add(this.dtpDenNgay);
			this.splitContainer1.Panel1.Controls.Add(this.dtpTuNgay);
			this.splitContainer1.Panel1.Controls.Add(this.btnSearch);
			this.splitContainer1.Panel1.Controls.Add(this.groupBox1);
			// 
			// splitContainer1.Panel2
			// 
			this.splitContainer1.Panel2.Controls.Add(this.dgvDSCatDo);
			this.splitContainer1.Panel2.Controls.Add(this.panel1);
			this.splitContainer1.Size = new System.Drawing.Size(984, 478);
			this.splitContainer1.SplitterDistance = 150;
			this.splitContainer1.TabIndex = 0;
			// 
			// chkPhieuChuaTra
			// 
			this.chkPhieuChuaTra.AutoSize = true;
			this.chkPhieuChuaTra.Checked = true;
			this.chkPhieuChuaTra.CheckState = System.Windows.Forms.CheckState.Checked;
			this.chkPhieuChuaTra.Location = new System.Drawing.Point(7, 223);
			this.chkPhieuChuaTra.Name = "chkPhieuChuaTra";
			this.chkPhieuChuaTra.Size = new System.Drawing.Size(142, 22);
			this.chkPhieuChuaTra.TabIndex = 10;
			this.chkPhieuChuaTra.Text = "Phiếu chưa trả đồ";
			this.chkPhieuChuaTra.UseVisualStyleBackColor = true;
			// 
			// chkTimTheoNgay
			// 
			this.chkTimTheoNgay.AutoSize = true;
			this.chkTimTheoNgay.Location = new System.Drawing.Point(7, 251);
			this.chkTimTheoNgay.Name = "chkTimTheoNgay";
			this.chkTimTheoNgay.Size = new System.Drawing.Size(141, 22);
			this.chkTimTheoNgay.TabIndex = 10;
			this.chkTimTheoNgay.Text = "Tìm theo ngày trả";
			this.chkTimTheoNgay.UseVisualStyleBackColor = true;
			this.chkTimTheoNgay.CheckedChanged += new System.EventHandler(this.chkTimTheoNgay_CheckedChanged);
			// 
			// lblDenNgay
			// 
			this.lblDenNgay.AutoSize = true;
			this.lblDenNgay.Location = new System.Drawing.Point(4, 338);
			this.lblDenNgay.Name = "lblDenNgay";
			this.lblDenNgay.Size = new System.Drawing.Size(74, 18);
			this.lblDenNgay.TabIndex = 9;
			this.lblDenNgay.Text = "Đến ngày:";
			this.lblDenNgay.Visible = false;
			// 
			// lblTuNgay
			// 
			this.lblTuNgay.AutoSize = true;
			this.lblTuNgay.Location = new System.Drawing.Point(4, 277);
			this.lblTuNgay.Name = "lblTuNgay";
			this.lblTuNgay.Size = new System.Drawing.Size(64, 18);
			this.lblTuNgay.TabIndex = 8;
			this.lblTuNgay.Text = "Từ ngày:";
			this.lblTuNgay.Visible = false;
			// 
			// dtpDenNgay
			// 
			this.dtpDenNgay.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
						| System.Windows.Forms.AnchorStyles.Right)));
			this.dtpDenNgay.CustomFormat = "dd/MM/yyyy";
			this.dtpDenNgay.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			this.dtpDenNgay.Location = new System.Drawing.Point(7, 366);
			this.dtpDenNgay.Name = "dtpDenNgay";
			this.dtpDenNgay.Size = new System.Drawing.Size(130, 24);
			this.dtpDenNgay.TabIndex = 6;
			this.dtpDenNgay.Visible = false;
			// 
			// dtpTuNgay
			// 
			this.dtpTuNgay.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
						| System.Windows.Forms.AnchorStyles.Right)));
			this.dtpTuNgay.CustomFormat = "dd/MM/yyyy";
			this.dtpTuNgay.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			this.dtpTuNgay.Location = new System.Drawing.Point(7, 306);
			this.dtpTuNgay.Name = "dtpTuNgay";
			this.dtpTuNgay.Size = new System.Drawing.Size(130, 24);
			this.dtpTuNgay.TabIndex = 7;
			this.dtpTuNgay.Visible = false;
			// 
			// btnSearch
			// 
			this.btnSearch.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.btnSearch.Image = global::QuanLyTiemGiatLa.Properties.Resources.search_4824;
			this.btnSearch.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnSearch.Location = new System.Drawing.Point(51, 170);
			this.btnSearch.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.btnSearch.Name = "btnSearch";
			this.btnSearch.Size = new System.Drawing.Size(92, 48);
			this.btnSearch.TabIndex = 0;
			this.btnSearch.Text = "Tì&m";
			this.btnSearch.UseVisualStyleBackColor = true;
			this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.Add(this.txtTenDo);
			this.groupBox1.Controls.Add(this.label6);
			this.groupBox1.Controls.Add(this.txtMaVach);
			this.groupBox1.Controls.Add(this.txtMaPhieu);
			this.groupBox1.Controls.Add(this.label4);
			this.groupBox1.Controls.Add(this.label1);
			this.groupBox1.Location = new System.Drawing.Point(7, -2);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(136, 167);
			this.groupBox1.TabIndex = 1;
			this.groupBox1.TabStop = false;
			// 
			// txtTenDo
			// 
			this.txtTenDo.Location = new System.Drawing.Point(9, 135);
			this.txtTenDo.Name = "txtTenDo";
			this.txtTenDo.Size = new System.Drawing.Size(121, 24);
			this.txtTenDo.TabIndex = 4;
			// 
			// label6
			// 
			this.label6.AutoSize = true;
			this.label6.Location = new System.Drawing.Point(6, 114);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(58, 18);
			this.label6.TabIndex = 6;
			this.label6.Text = "Tên đồ:";
			// 
			// txtMaVach
			// 
			this.txtMaVach.Location = new System.Drawing.Point(10, 87);
			this.txtMaVach.Name = "txtMaVach";
			this.txtMaVach.Size = new System.Drawing.Size(120, 24);
			this.txtMaVach.TabIndex = 3;
			// 
			// txtMaPhieu
			// 
			this.txtMaPhieu.Location = new System.Drawing.Point(10, 40);
			this.txtMaPhieu.Name = "txtMaPhieu";
			this.txtMaPhieu.Size = new System.Drawing.Size(120, 24);
			this.txtMaPhieu.TabIndex = 1;
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(6, 67);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(68, 18);
			this.label4.TabIndex = 2;
			this.label4.Text = "Mã vạch:";
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(6, 20);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(72, 18);
			this.label1.TabIndex = 0;
			this.label1.Text = "Mã phiếu:";
			// 
			// dgvDSCatDo
			// 
			this.dgvDSCatDo.AllowUserToAddRows = false;
			this.dgvDSCatDo.AllowUserToDeleteRows = false;
			this.dgvDSCatDo.AutoGenerateColumns = false;
			this.dgvDSCatDo.BackgroundColor = System.Drawing.SystemColors.Control;
			this.dgvDSCatDo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dgvDSCatDo.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.maPhieuDataGridViewTextBoxColumn,
            this.sTTDataGridViewTextBoxColumn,
            this.maHangDataGridViewTextBoxColumn,
            this.maKieuGiatDataGridViewTextBoxColumn,
            this.maHienThiDataGridViewTextBoxColumn,
            this.maVachDataGridViewTextBoxColumn,
            this.tenHangDataGridViewTextBoxColumn,
            this.SoHieuSanPham,
            this.tenKieuGiatDataGridViewTextBoxColumn,
            this.khoDataGridViewTextBoxColumn,
            this.slotDataGridViewTextBoxColumn,
            this.daTraDataGridViewCheckBoxColumn,
            this.ghichuDataGridViewTextBoxColumn,
            this.ThoiDiemLuu,
            this.NgayTraDataGridViewTextBoxColumn});
			this.dgvDSCatDo.DataSource = this.bndsrcDSCatDo;
			this.dgvDSCatDo.Dock = System.Windows.Forms.DockStyle.Fill;
			this.dgvDSCatDo.Location = new System.Drawing.Point(0, 0);
			this.dgvDSCatDo.Name = "dgvDSCatDo";
			this.dgvDSCatDo.RowHeadersWidth = 25;
			this.dgvDSCatDo.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
			this.dgvDSCatDo.Size = new System.Drawing.Size(826, 409);
			this.dgvDSCatDo.TabIndex = 0;
			this.dgvDSCatDo.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvDSCatDo_CellDoubleClick);
			// 
			// maPhieuDataGridViewTextBoxColumn
			// 
			this.maPhieuDataGridViewTextBoxColumn.DataPropertyName = "MaPhieu";
			this.maPhieuDataGridViewTextBoxColumn.HeaderText = "MaPhieu";
			this.maPhieuDataGridViewTextBoxColumn.Name = "maPhieuDataGridViewTextBoxColumn";
			this.maPhieuDataGridViewTextBoxColumn.Visible = false;
			// 
			// sTTDataGridViewTextBoxColumn
			// 
			this.sTTDataGridViewTextBoxColumn.DataPropertyName = "STT";
			this.sTTDataGridViewTextBoxColumn.HeaderText = "STT";
			this.sTTDataGridViewTextBoxColumn.Name = "sTTDataGridViewTextBoxColumn";
			this.sTTDataGridViewTextBoxColumn.Visible = false;
			// 
			// maHangDataGridViewTextBoxColumn
			// 
			this.maHangDataGridViewTextBoxColumn.DataPropertyName = "MaHang";
			this.maHangDataGridViewTextBoxColumn.HeaderText = "MaHang";
			this.maHangDataGridViewTextBoxColumn.Name = "maHangDataGridViewTextBoxColumn";
			this.maHangDataGridViewTextBoxColumn.Visible = false;
			// 
			// maKieuGiatDataGridViewTextBoxColumn
			// 
			this.maKieuGiatDataGridViewTextBoxColumn.DataPropertyName = "MaKieuGiat";
			this.maKieuGiatDataGridViewTextBoxColumn.HeaderText = "MaKieuGiat";
			this.maKieuGiatDataGridViewTextBoxColumn.Name = "maKieuGiatDataGridViewTextBoxColumn";
			this.maKieuGiatDataGridViewTextBoxColumn.Visible = false;
			// 
			// maHienThiDataGridViewTextBoxColumn
			// 
			this.maHienThiDataGridViewTextBoxColumn.DataPropertyName = "MaHienThi";
			this.maHienThiDataGridViewTextBoxColumn.HeaderText = "Mã đồ";
			this.maHienThiDataGridViewTextBoxColumn.Name = "maHienThiDataGridViewTextBoxColumn";
			this.maHienThiDataGridViewTextBoxColumn.ReadOnly = true;
			this.maHienThiDataGridViewTextBoxColumn.Width = 80;
			// 
			// maVachDataGridViewTextBoxColumn
			// 
			this.maVachDataGridViewTextBoxColumn.DataPropertyName = "MaVach";
			this.maVachDataGridViewTextBoxColumn.HeaderText = "Mã vạch";
			this.maVachDataGridViewTextBoxColumn.Name = "maVachDataGridViewTextBoxColumn";
			this.maVachDataGridViewTextBoxColumn.ReadOnly = true;
			this.maVachDataGridViewTextBoxColumn.Width = 90;
			// 
			// tenHangDataGridViewTextBoxColumn
			// 
			this.tenHangDataGridViewTextBoxColumn.DataPropertyName = "TenHang";
			this.tenHangDataGridViewTextBoxColumn.HeaderText = "Tên đồ";
			this.tenHangDataGridViewTextBoxColumn.Name = "tenHangDataGridViewTextBoxColumn";
			this.tenHangDataGridViewTextBoxColumn.ReadOnly = true;
			// 
			// SoHieuSanPham
			// 
			this.SoHieuSanPham.DataPropertyName = "SoHieuSanPham";
			this.SoHieuSanPham.HeaderText = "SHSP";
			this.SoHieuSanPham.Name = "SoHieuSanPham";
			this.SoHieuSanPham.ReadOnly = true;
			this.SoHieuSanPham.Width = 50;
			// 
			// tenKieuGiatDataGridViewTextBoxColumn
			// 
			this.tenKieuGiatDataGridViewTextBoxColumn.DataPropertyName = "TenKieuGiat";
			this.tenKieuGiatDataGridViewTextBoxColumn.HeaderText = "Kiểu giặt";
			this.tenKieuGiatDataGridViewTextBoxColumn.Name = "tenKieuGiatDataGridViewTextBoxColumn";
			this.tenKieuGiatDataGridViewTextBoxColumn.ReadOnly = true;
			this.tenKieuGiatDataGridViewTextBoxColumn.Width = 90;
			// 
			// khoDataGridViewTextBoxColumn
			// 
			this.khoDataGridViewTextBoxColumn.DataPropertyName = "Kho";
			this.khoDataGridViewTextBoxColumn.HeaderText = "Kho";
			this.khoDataGridViewTextBoxColumn.Name = "khoDataGridViewTextBoxColumn";
			this.khoDataGridViewTextBoxColumn.Width = 50;
			// 
			// slotDataGridViewTextBoxColumn
			// 
			this.slotDataGridViewTextBoxColumn.DataPropertyName = "Slot";
			this.slotDataGridViewTextBoxColumn.HeaderText = "Slot";
			this.slotDataGridViewTextBoxColumn.Name = "slotDataGridViewTextBoxColumn";
			this.slotDataGridViewTextBoxColumn.Width = 60;
			// 
			// daTraDataGridViewCheckBoxColumn
			// 
			this.daTraDataGridViewCheckBoxColumn.DataPropertyName = "DaTra";
			this.daTraDataGridViewCheckBoxColumn.HeaderText = "Đã trả";
			this.daTraDataGridViewCheckBoxColumn.Name = "daTraDataGridViewCheckBoxColumn";
			this.daTraDataGridViewCheckBoxColumn.Width = 60;
			// 
			// ghichuDataGridViewTextBoxColumn
			// 
			this.ghichuDataGridViewTextBoxColumn.DataPropertyName = "GhiChu";
			this.ghichuDataGridViewTextBoxColumn.HeaderText = "Ghi chú";
			this.ghichuDataGridViewTextBoxColumn.Name = "ghichuDataGridViewTextBoxColumn";
			this.ghichuDataGridViewTextBoxColumn.Width = 200;
			// 
			// ThoiDiemLuu
			// 
			this.ThoiDiemLuu.DataPropertyName = "ThoiDiemLuu";
			this.ThoiDiemLuu.HeaderText = "Tg lưu";
			this.ThoiDiemLuu.Name = "ThoiDiemLuu";
			this.ThoiDiemLuu.ReadOnly = true;
			this.ThoiDiemLuu.Width = 95;
			// 
			// NgayTraDataGridViewTextBoxColumn
			// 
			this.NgayTraDataGridViewTextBoxColumn.DataPropertyName = "NgayTra";
			this.NgayTraDataGridViewTextBoxColumn.HeaderText = "Ngày trả";
			this.NgayTraDataGridViewTextBoxColumn.Name = "NgayTraDataGridViewTextBoxColumn";
			this.NgayTraDataGridViewTextBoxColumn.Width = 125;
			// 
			// bndsrcDSCatDo
			// 
			this.bndsrcDSCatDo.DataSource = typeof(Entity.ListPhieuSlotEntity);
			// 
			// panel1
			// 
			this.panel1.Controls.Add(this.txtSoDienThoai);
			this.panel1.Controls.Add(this.label3);
			this.panel1.Controls.Add(this.txtTenKhachHang);
			this.panel1.Controls.Add(this.label2);
			this.panel1.Controls.Add(this.btnThoat);
			this.panel1.Controls.Add(this.btnGhi);
			this.panel1.Controls.Add(this.btnXemKhachHang);
			this.panel1.Controls.Add(this.btnXemPhieu);
			this.panel1.Controls.Add(this.btnCollapse);
			this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.panel1.Location = new System.Drawing.Point(0, 409);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(826, 65);
			this.panel1.TabIndex = 1;
			// 
			// txtSoDienThoai
			// 
			this.txtSoDienThoai.BackColor = System.Drawing.SystemColors.ControlLightLight;
			this.txtSoDienThoai.Location = new System.Drawing.Point(395, 34);
			this.txtSoDienThoai.Name = "txtSoDienThoai";
			this.txtSoDienThoai.ReadOnly = true;
			this.txtSoDienThoai.Size = new System.Drawing.Size(143, 24);
			this.txtSoDienThoai.TabIndex = 6;
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(282, 37);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(98, 18);
			this.label3.TabIndex = 4;
			this.label3.Text = "Số điện thoại:";
			// 
			// txtTenKhachHang
			// 
			this.txtTenKhachHang.BackColor = System.Drawing.SystemColors.ControlLightLight;
			this.txtTenKhachHang.Location = new System.Drawing.Point(395, 7);
			this.txtTenKhachHang.Name = "txtTenKhachHang";
			this.txtTenKhachHang.ReadOnly = true;
			this.txtTenKhachHang.Size = new System.Drawing.Size(143, 24);
			this.txtTenKhachHang.TabIndex = 5;
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(282, 10);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(117, 18);
			this.label2.TabIndex = 3;
			this.label2.Text = "Tên khách hàng:";
			// 
			// btnThoat
			// 
			this.btnThoat.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.btnThoat.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.btnThoat.Image = global::QuanLyTiemGiatLa.Properties.Resources.Exit16;
			this.btnThoat.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnThoat.Location = new System.Drawing.Point(727, 6);
			this.btnThoat.Name = "btnThoat";
			this.btnThoat.Size = new System.Drawing.Size(89, 52);
			this.btnThoat.TabIndex = 8;
			this.btnThoat.Text = "&Thoát";
			this.btnThoat.UseVisualStyleBackColor = true;
			this.btnThoat.Click += new System.EventHandler(this.btnThoat_Click);
			// 
			// btnGhi
			// 
			this.btnGhi.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.btnGhi.Image = global::QuanLyTiemGiatLa.Properties.Resources._45;
			this.btnGhi.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnGhi.Location = new System.Drawing.Point(616, 6);
			this.btnGhi.Name = "btnGhi";
			this.btnGhi.Size = new System.Drawing.Size(105, 52);
			this.btnGhi.TabIndex = 7;
			this.btnGhi.Text = "&Ghi (F4)";
			this.btnGhi.UseVisualStyleBackColor = true;
			this.btnGhi.Click += new System.EventHandler(this.btnGhi_Click);
			// 
			// btnXemKhachHang
			// 
			this.btnXemKhachHang.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.btnXemKhachHang.Location = new System.Drawing.Point(180, 6);
			this.btnXemKhachHang.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.btnXemKhachHang.Name = "btnXemKhachHang";
			this.btnXemKhachHang.Size = new System.Drawing.Size(96, 50);
			this.btnXemKhachHang.TabIndex = 2;
			this.btnXemKhachHang.Text = "Xem khách hàng (F3)";
			this.btnXemKhachHang.UseVisualStyleBackColor = true;
			this.btnXemKhachHang.Click += new System.EventHandler(this.btnXemKhachHang_Click);
			// 
			// btnXemPhieu
			// 
			this.btnXemPhieu.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.btnXemPhieu.Location = new System.Drawing.Point(78, 6);
			this.btnXemPhieu.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.btnXemPhieu.Name = "btnXemPhieu";
			this.btnXemPhieu.Size = new System.Drawing.Size(96, 50);
			this.btnXemPhieu.TabIndex = 1;
			this.btnXemPhieu.Text = "&Xem phiếu (F1)";
			this.btnXemPhieu.UseVisualStyleBackColor = true;
			this.btnXemPhieu.Click += new System.EventHandler(this.btnXemPhieu_Click);
			// 
			// btnCollapse
			// 
			this.btnCollapse.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.btnCollapse.Location = new System.Drawing.Point(3, 6);
			this.btnCollapse.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.btnCollapse.Name = "btnCollapse";
			this.btnCollapse.Size = new System.Drawing.Size(69, 50);
			this.btnCollapse.TabIndex = 0;
			this.btnCollapse.Text = "<<";
			this.btnCollapse.UseVisualStyleBackColor = true;
			this.btnCollapse.Click += new System.EventHandler(this.btnCollapse_Click);
			// 
			// contextMenuStrip1
			// 
			this.contextMenuStrip1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ghiToolStripMenuItem,
            this.xemPhieuToolStripMenuItem,
            this.xemKhachHangToolStripMenuItem});
			this.contextMenuStrip1.Name = "contextMenuStrip1";
			this.contextMenuStrip1.Size = new System.Drawing.Size(223, 82);
			// 
			// ghiToolStripMenuItem
			// 
			this.ghiToolStripMenuItem.Name = "ghiToolStripMenuItem";
			this.ghiToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F4;
			this.ghiToolStripMenuItem.Size = new System.Drawing.Size(222, 26);
			this.ghiToolStripMenuItem.Text = "Ghi";
			this.ghiToolStripMenuItem.Visible = false;
			this.ghiToolStripMenuItem.Click += new System.EventHandler(this.ghiToolStripMenuItem_Click);
			// 
			// xemPhieuToolStripMenuItem
			// 
			this.xemPhieuToolStripMenuItem.Name = "xemPhieuToolStripMenuItem";
			this.xemPhieuToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F1;
			this.xemPhieuToolStripMenuItem.Size = new System.Drawing.Size(222, 26);
			this.xemPhieuToolStripMenuItem.Text = "Xem phieu";
			this.xemPhieuToolStripMenuItem.Visible = false;
			this.xemPhieuToolStripMenuItem.Click += new System.EventHandler(this.xemPhieuToolStripMenuItem_Click);
			// 
			// xemKhachHangToolStripMenuItem
			// 
			this.xemKhachHangToolStripMenuItem.Name = "xemKhachHangToolStripMenuItem";
			this.xemKhachHangToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F3;
			this.xemKhachHangToolStripMenuItem.Size = new System.Drawing.Size(222, 26);
			this.xemKhachHangToolStripMenuItem.Text = "Xem khach hang";
			this.xemKhachHangToolStripMenuItem.Visible = false;
			this.xemKhachHangToolStripMenuItem.Click += new System.EventHandler(this.xemKhachHangToolStripMenuItem_Click);
			// 
			// frmCatDo
			// 
			this.AcceptButton = this.btnSearch;
			this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.CancelButton = this.btnThoat;
			this.ClientSize = new System.Drawing.Size(984, 478);
			this.ContextMenuStrip = this.contextMenuStrip1;
			this.Controls.Add(this.splitContainer1);
			this.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Margin = new System.Windows.Forms.Padding(4);
			this.Name = "frmCatDo";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Cất đồ đã giặt";
			this.splitContainer1.Panel1.ResumeLayout(false);
			this.splitContainer1.Panel1.PerformLayout();
			this.splitContainer1.Panel2.ResumeLayout(false);
			this.splitContainer1.ResumeLayout(false);
			this.groupBox1.ResumeLayout(false);
			this.groupBox1.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.dgvDSCatDo)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.bndsrcDSCatDo)).EndInit();
			this.panel1.ResumeLayout(false);
			this.panel1.PerformLayout();
			this.contextMenuStrip1.ResumeLayout(false);
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.SplitContainer splitContainer1;
		private System.Windows.Forms.Button btnSearch;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.TextBox txtMaVach;
		private System.Windows.Forms.TextBox txtMaPhieu;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.DataGridView dgvDSCatDo;
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.Button btnThoat;
		private System.Windows.Forms.Button btnGhi;
		private System.Windows.Forms.Button btnCollapse;
		private System.Windows.Forms.BindingSource bndsrcDSCatDo;
		private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
		private System.Windows.Forms.ToolStripMenuItem ghiToolStripMenuItem;
		private System.Windows.Forms.Button btnXemPhieu;
		private System.Windows.Forms.ToolStripMenuItem xemPhieuToolStripMenuItem;
		private System.Windows.Forms.TextBox txtTenDo;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Button btnXemKhachHang;
		private System.Windows.Forms.ToolStripMenuItem xemKhachHangToolStripMenuItem;
		private System.Windows.Forms.TextBox txtSoDienThoai;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.TextBox txtTenKhachHang;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.CheckBox chkTimTheoNgay;
		private System.Windows.Forms.Label lblDenNgay;
		private System.Windows.Forms.Label lblTuNgay;
		private System.Windows.Forms.DateTimePicker dtpDenNgay;
		private System.Windows.Forms.DateTimePicker dtpTuNgay;
        private System.Windows.Forms.CheckBox chkPhieuChuaTra;
        private System.Windows.Forms.DataGridViewTextBoxColumn maPhieuDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sTTDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn maHangDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn maKieuGiatDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn maHienThiDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn maVachDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tenHangDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn SoHieuSanPham;
        private System.Windows.Forms.DataGridViewTextBoxColumn tenKieuGiatDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn khoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn slotDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewCheckBoxColumn daTraDataGridViewCheckBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn ghichuDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn ThoiDiemLuu;
        private System.Windows.Forms.DataGridViewTextBoxColumn NgayTraDataGridViewTextBoxColumn;
	}
}