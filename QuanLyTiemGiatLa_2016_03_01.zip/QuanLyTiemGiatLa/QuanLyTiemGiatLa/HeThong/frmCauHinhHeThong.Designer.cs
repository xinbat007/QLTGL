﻿namespace QuanLyTiemGiatLa.HeThong
{
	partial class frmCauHinhHeThong
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmCauHinhHeThong));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.cboCatDoFocus = new System.Windows.Forms.ComboBox();
            this.cboKhoMayIn = new System.Windows.Forms.ComboBox();
            this.chkToanManHinh = new System.Windows.Forms.CheckBox();
            this.label23 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.nudSoLanIn = new System.Windows.Forms.NumericUpDown();
            this.nudViecCanLam = new System.Windows.Forms.NumericUpDown();
            this.nudNgayLapTra = new System.Windows.Forms.NumericUpDown();
            this.nudPhiVanChuyen = new System.Windows.Forms.NumericUpDown();
            this.nudGiatNhanhTangGia = new System.Windows.Forms.NumericUpDown();
            this.nudTreEmGiamGia = new System.Windows.Forms.NumericUpDown();
            this.label10 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.txtMaVach = new System.Windows.Forms.TextBox();
            this.chkDungMaVach = new System.Windows.Forms.CheckBox();
            this.btnThoat = new System.Windows.Forms.Button();
            this.btnGhi = new System.Windows.Forms.Button();
            this.btnBackUp = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txtXoayVongDen = new System.Windows.Forms.TextBox();
            this.txtXoayVongTu = new System.Windows.Forms.TextBox();
            this.btnMauDoDaTra = new System.Windows.Forms.Button();
            this.btnMauDoGhiChu = new System.Windows.Forms.Button();
            this.btnMauDoDaGiat = new System.Windows.Forms.Button();
            this.btnMauDoChuaGiat = new System.Windows.Forms.Button();
            this.txtDienThoaiCuaHang = new System.Windows.Forms.TextBox();
            this.txtDiaChi = new System.Windows.Forms.TextBox();
            this.txtTenCuaHang = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.btnMauDoPhieuHuy = new System.Windows.Forms.Button();
            this.label24 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudSoLanIn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudViecCanLam)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudNgayLapTra)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudPhiVanChuyen)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudGiatNhanhTangGia)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudTreEmGiamGia)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)));
            this.groupBox1.Controls.Add(this.cboCatDoFocus);
            this.groupBox1.Controls.Add(this.cboKhoMayIn);
            this.groupBox1.Controls.Add(this.chkToanManHinh);
            this.groupBox1.Controls.Add(this.label23);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.nudSoLanIn);
            this.groupBox1.Controls.Add(this.nudViecCanLam);
            this.groupBox1.Controls.Add(this.nudNgayLapTra);
            this.groupBox1.Controls.Add(this.nudPhiVanChuyen);
            this.groupBox1.Controls.Add(this.nudGiatNhanhTangGia);
            this.groupBox1.Controls.Add(this.nudTreEmGiamGia);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label22);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Location = new System.Drawing.Point(12, 1);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(315, 349);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            // 
            // cboCatDoFocus
            // 
            this.cboCatDoFocus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboCatDoFocus.FormattingEnabled = true;
            this.cboCatDoFocus.Items.AddRange(new object[] {
            "Mã phiếu",
            "Mã vạch"});
            this.cboCatDoFocus.Location = new System.Drawing.Point(193, 250);
            this.cboCatDoFocus.Name = "cboCatDoFocus";
            this.cboCatDoFocus.Size = new System.Drawing.Size(114, 28);
            this.cboCatDoFocus.TabIndex = 7;
            // 
            // cboKhoMayIn
            // 
            this.cboKhoMayIn.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboKhoMayIn.FormattingEnabled = true;
            this.cboKhoMayIn.Items.AddRange(new object[] {
            "Khổ nhỏ",
            "Khổ to 8cm"});
            this.cboKhoMayIn.Location = new System.Drawing.Point(193, 218);
            this.cboKhoMayIn.Name = "cboKhoMayIn";
            this.cboKhoMayIn.Size = new System.Drawing.Size(114, 28);
            this.cboKhoMayIn.TabIndex = 6;
            // 
            // chkToanManHinh
            // 
            this.chkToanManHinh.AutoSize = true;
            this.chkToanManHinh.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.chkToanManHinh.Location = new System.Drawing.Point(70, 286);
            this.chkToanManHinh.Name = "chkToanManHinh";
            this.chkToanManHinh.Size = new System.Drawing.Size(137, 24);
            this.chkToanManHinh.TabIndex = 8;
            this.chkToanManHinh.Text = "Toàn màn hình:";
            this.chkToanManHinh.UseVisualStyleBackColor = true;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(264, 88);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(23, 20);
            this.label23.TabIndex = 3;
            this.label23.Text = "%";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(264, 57);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(23, 20);
            this.label4.TabIndex = 3;
            this.label4.Text = "%";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(264, 22);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(23, 20);
            this.label3.TabIndex = 3;
            this.label3.Text = "%";
            // 
            // nudSoLanIn
            // 
            this.nudSoLanIn.Location = new System.Drawing.Point(193, 184);
            this.nudSoLanIn.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudSoLanIn.Name = "nudSoLanIn";
            this.nudSoLanIn.Size = new System.Drawing.Size(65, 26);
            this.nudSoLanIn.TabIndex = 5;
            this.nudSoLanIn.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // nudViecCanLam
            // 
            this.nudViecCanLam.Location = new System.Drawing.Point(193, 152);
            this.nudViecCanLam.Name = "nudViecCanLam";
            this.nudViecCanLam.Size = new System.Drawing.Size(65, 26);
            this.nudViecCanLam.TabIndex = 4;
            // 
            // nudNgayLapTra
            // 
            this.nudNgayLapTra.Location = new System.Drawing.Point(193, 119);
            this.nudNgayLapTra.Name = "nudNgayLapTra";
            this.nudNgayLapTra.Size = new System.Drawing.Size(65, 26);
            this.nudNgayLapTra.TabIndex = 3;
            // 
            // nudPhiVanChuyen
            // 
            this.nudPhiVanChuyen.Location = new System.Drawing.Point(193, 84);
            this.nudPhiVanChuyen.Name = "nudPhiVanChuyen";
            this.nudPhiVanChuyen.Size = new System.Drawing.Size(65, 26);
            this.nudPhiVanChuyen.TabIndex = 2;
            // 
            // nudGiatNhanhTangGia
            // 
            this.nudGiatNhanhTangGia.Location = new System.Drawing.Point(193, 51);
            this.nudGiatNhanhTangGia.Name = "nudGiatNhanhTangGia";
            this.nudGiatNhanhTangGia.Size = new System.Drawing.Size(65, 26);
            this.nudGiatNhanhTangGia.TabIndex = 1;
            // 
            // nudTreEmGiamGia
            // 
            this.nudTreEmGiamGia.Location = new System.Drawing.Point(193, 20);
            this.nudTreEmGiamGia.Name = "nudTreEmGiamGia";
            this.nudTreEmGiamGia.Size = new System.Drawing.Size(65, 26);
            this.nudTreEmGiamGia.TabIndex = 0;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(84, 253);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(103, 20);
            this.label10.TabIndex = 1;
            this.label10.Text = "Cất đồ focus:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(113, 186);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(74, 20);
            this.label12.TabIndex = 1;
            this.label12.Text = "Số lần in:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(97, 221);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(90, 20);
            this.label9.TabIndex = 1;
            this.label9.Text = "Khổ máy in:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 154);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(181, 20);
            this.label6.TabIndex = 1;
            this.label6.Text = "Việc cần làm cách nhau:";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(68, 86);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(119, 20);
            this.label22.TabIndex = 1;
            this.label22.Text = "Phí vận chuyển:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(3, 121);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(184, 20);
            this.label5.TabIndex = 1;
            this.label5.Text = "Ngày lập -> ngày hẹn trả:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(30, 53);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(157, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Giặt nhanh, tăng giá:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(264, 186);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(30, 20);
            this.label11.TabIndex = 0;
            this.label11.Text = "lần";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(58, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(129, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Trẻ em, giảm giá:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(264, 154);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(43, 20);
            this.label8.TabIndex = 0;
            this.label8.Text = "ngày";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(264, 121);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(43, 20);
            this.label7.TabIndex = 0;
            this.label7.Text = "ngày";
            // 
            // txtMaVach
            // 
            this.txtMaVach.Location = new System.Drawing.Point(146, 284);
            this.txtMaVach.Name = "txtMaVach";
            this.txtMaVach.Size = new System.Drawing.Size(75, 26);
            this.txtMaVach.TabIndex = 9;
            // 
            // chkDungMaVach
            // 
            this.chkDungMaVach.AutoSize = true;
            this.chkDungMaVach.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.chkDungMaVach.Location = new System.Drawing.Point(6, 286);
            this.chkDungMaVach.Name = "chkDungMaVach";
            this.chkDungMaVach.Size = new System.Drawing.Size(134, 24);
            this.chkDungMaVach.TabIndex = 8;
            this.chkDungMaVach.Text = "Dùng mã vạch:";
            this.chkDungMaVach.UseVisualStyleBackColor = true;
            // 
            // btnThoat
            // 
            this.btnThoat.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnThoat.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnThoat.Image = global::QuanLyTiemGiatLa.Properties.Resources.Exit16;
            this.btnThoat.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnThoat.Location = new System.Drawing.Point(562, 359);
            this.btnThoat.Name = "btnThoat";
            this.btnThoat.Size = new System.Drawing.Size(89, 47);
            this.btnThoat.TabIndex = 4;
            this.btnThoat.Text = "&Thoát";
            this.btnThoat.UseVisualStyleBackColor = true;
            this.btnThoat.Click += new System.EventHandler(this.btnThoat_Click);
            // 
            // btnGhi
            // 
            this.btnGhi.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnGhi.Image = global::QuanLyTiemGiatLa.Properties.Resources._45;
            this.btnGhi.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnGhi.Location = new System.Drawing.Point(477, 359);
            this.btnGhi.Name = "btnGhi";
            this.btnGhi.Size = new System.Drawing.Size(79, 47);
            this.btnGhi.TabIndex = 3;
            this.btnGhi.Text = "&Ghi";
            this.btnGhi.UseVisualStyleBackColor = true;
            this.btnGhi.Click += new System.EventHandler(this.btnGhi_Click);
            // 
            // btnBackUp
            // 
            this.btnBackUp.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnBackUp.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnBackUp.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnBackUp.Location = new System.Drawing.Point(12, 359);
            this.btnBackUp.Name = "btnBackUp";
            this.btnBackUp.Size = new System.Drawing.Size(89, 47);
            this.btnBackUp.TabIndex = 2;
            this.btnBackUp.Text = "Backup ...";
            this.btnBackUp.UseVisualStyleBackColor = true;
            this.btnBackUp.Click += new System.EventHandler(this.btnBackUp_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)));
            this.groupBox2.Controls.Add(this.btnMauDoPhieuHuy);
            this.groupBox2.Controls.Add(this.label24);
            this.groupBox2.Controls.Add(this.txtXoayVongDen);
            this.groupBox2.Controls.Add(this.txtXoayVongTu);
            this.groupBox2.Controls.Add(this.txtMaVach);
            this.groupBox2.Controls.Add(this.chkDungMaVach);
            this.groupBox2.Controls.Add(this.btnMauDoDaTra);
            this.groupBox2.Controls.Add(this.btnMauDoGhiChu);
            this.groupBox2.Controls.Add(this.btnMauDoDaGiat);
            this.groupBox2.Controls.Add(this.btnMauDoChuaGiat);
            this.groupBox2.Controls.Add(this.txtDienThoaiCuaHang);
            this.groupBox2.Controls.Add(this.txtDiaChi);
            this.groupBox2.Controls.Add(this.txtTenCuaHang);
            this.groupBox2.Controls.Add(this.label19);
            this.groupBox2.Controls.Add(this.label18);
            this.groupBox2.Controls.Add(this.label17);
            this.groupBox2.Controls.Add(this.label16);
            this.groupBox2.Controls.Add(this.label21);
            this.groupBox2.Controls.Add(this.label20);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Location = new System.Drawing.Point(333, 1);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(318, 349);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            // 
            // txtXoayVongDen
            // 
            this.txtXoayVongDen.Location = new System.Drawing.Point(239, 316);
            this.txtXoayVongDen.Name = "txtXoayVongDen";
            this.txtXoayVongDen.Size = new System.Drawing.Size(75, 26);
            this.txtXoayVongDen.TabIndex = 11;
            // 
            // txtXoayVongTu
            // 
            this.txtXoayVongTu.Location = new System.Drawing.Point(146, 316);
            this.txtXoayVongTu.Name = "txtXoayVongTu";
            this.txtXoayVongTu.Size = new System.Drawing.Size(75, 26);
            this.txtXoayVongTu.TabIndex = 10;
            // 
            // btnMauDoDaTra
            // 
            this.btnMauDoDaTra.Location = new System.Drawing.Point(144, 217);
            this.btnMauDoDaTra.Name = "btnMauDoDaTra";
            this.btnMauDoDaTra.Size = new System.Drawing.Size(75, 28);
            this.btnMauDoDaTra.TabIndex = 6;
            this.btnMauDoDaTra.UseVisualStyleBackColor = true;
            this.btnMauDoDaTra.Click += new System.EventHandler(this.btnMauDoDaTra_Click);
            // 
            // btnMauDoGhiChu
            // 
            this.btnMauDoGhiChu.Location = new System.Drawing.Point(144, 183);
            this.btnMauDoGhiChu.Name = "btnMauDoGhiChu";
            this.btnMauDoGhiChu.Size = new System.Drawing.Size(75, 28);
            this.btnMauDoGhiChu.TabIndex = 5;
            this.btnMauDoGhiChu.UseVisualStyleBackColor = true;
            this.btnMauDoGhiChu.Click += new System.EventHandler(this.btnMauDoGhiChu_Click);
            // 
            // btnMauDoDaGiat
            // 
            this.btnMauDoDaGiat.Location = new System.Drawing.Point(144, 149);
            this.btnMauDoDaGiat.Name = "btnMauDoDaGiat";
            this.btnMauDoDaGiat.Size = new System.Drawing.Size(75, 28);
            this.btnMauDoDaGiat.TabIndex = 4;
            this.btnMauDoDaGiat.UseVisualStyleBackColor = true;
            this.btnMauDoDaGiat.Click += new System.EventHandler(this.btnMauDoDaGiat_Click);
            // 
            // btnMauDoChuaGiat
            // 
            this.btnMauDoChuaGiat.Location = new System.Drawing.Point(144, 115);
            this.btnMauDoChuaGiat.Name = "btnMauDoChuaGiat";
            this.btnMauDoChuaGiat.Size = new System.Drawing.Size(75, 28);
            this.btnMauDoChuaGiat.TabIndex = 3;
            this.btnMauDoChuaGiat.UseVisualStyleBackColor = true;
            this.btnMauDoChuaGiat.Click += new System.EventHandler(this.btnMauDoChuaGiat_Click);
            // 
            // txtDienThoaiCuaHang
            // 
            this.txtDienThoaiCuaHang.Location = new System.Drawing.Point(144, 83);
            this.txtDienThoaiCuaHang.Name = "txtDienThoaiCuaHang";
            this.txtDienThoaiCuaHang.Size = new System.Drawing.Size(168, 26);
            this.txtDienThoaiCuaHang.TabIndex = 2;
            // 
            // txtDiaChi
            // 
            this.txtDiaChi.Location = new System.Drawing.Point(144, 51);
            this.txtDiaChi.Name = "txtDiaChi";
            this.txtDiaChi.Size = new System.Drawing.Size(168, 26);
            this.txtDiaChi.TabIndex = 1;
            // 
            // txtTenCuaHang
            // 
            this.txtTenCuaHang.Location = new System.Drawing.Point(144, 19);
            this.txtTenCuaHang.Name = "txtTenCuaHang";
            this.txtTenCuaHang.Size = new System.Drawing.Size(168, 26);
            this.txtTenCuaHang.TabIndex = 0;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(5, 55);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(61, 20);
            this.label19.TabIndex = 0;
            this.label19.Text = "Địa chỉ:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(5, 88);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(106, 20);
            this.label18.TabIndex = 0;
            this.label18.Text = "Số điện thoại:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(5, 22);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(110, 20);
            this.label17.TabIndex = 0;
            this.label17.Text = "Tên cửa hàng:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(5, 121);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(135, 20);
            this.label16.TabIndex = 0;
            this.label16.Text = "Màu đồ chưa giặt:";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(219, 320);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(23, 20);
            this.label21.TabIndex = 0;
            this.label21.Text = "->";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(8, 319);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(131, 20);
            this.label20.TabIndex = 0;
            this.label20.Text = "Xoay vòng mã từ:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(5, 220);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(111, 20);
            this.label15.TabIndex = 0;
            this.label15.Text = "Màu đồ đã trả:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(5, 154);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(118, 20);
            this.label14.TabIndex = 0;
            this.label14.Text = "Màu đồ đã giặt:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(5, 187);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(121, 20);
            this.label13.TabIndex = 0;
            this.label13.Text = "Màu đồ ghi chú:";
            // 
            // btnMauDoPhieuHuy
            // 
            this.btnMauDoPhieuHuy.Location = new System.Drawing.Point(144, 250);
            this.btnMauDoPhieuHuy.Name = "btnMauDoPhieuHuy";
            this.btnMauDoPhieuHuy.Size = new System.Drawing.Size(75, 28);
            this.btnMauDoPhieuHuy.TabIndex = 7;
            this.btnMauDoPhieuHuy.UseVisualStyleBackColor = true;
            this.btnMauDoPhieuHuy.Click += new System.EventHandler(this.btnMauDoPhieuHuy_Click);
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(5, 253);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(138, 20);
            this.label24.TabIndex = 10;
            this.label24.Text = "Màu đồ phiếu hủy:";
            // 
            // frmCauHinhHeThong
            // 
            this.AcceptButton = this.btnGhi;
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnThoat;
            this.ClientSize = new System.Drawing.Size(663, 418);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.btnGhi);
            this.Controls.Add(this.btnBackUp);
            this.Controls.Add(this.btnThoat);
            this.Controls.Add(this.groupBox1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "frmCauHinhHeThong";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Cấu hình hệ thống";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudSoLanIn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudViecCanLam)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudNgayLapTra)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudPhiVanChuyen)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudGiatNhanhTangGia)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudTreEmGiamGia)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Button btnThoat;
		private System.Windows.Forms.Button btnGhi;
		private System.Windows.Forms.NumericUpDown nudGiatNhanhTangGia;
		private System.Windows.Forms.NumericUpDown nudTreEmGiamGia;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.NumericUpDown nudViecCanLam;
		private System.Windows.Forms.NumericUpDown nudNgayLapTra;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.ComboBox cboKhoMayIn;
		private System.Windows.Forms.Label label9;
		private System.Windows.Forms.Label label10;
		private System.Windows.Forms.ComboBox cboCatDoFocus;
		private System.Windows.Forms.NumericUpDown nudSoLanIn;
		private System.Windows.Forms.Label label12;
		private System.Windows.Forms.Label label11;
		private System.Windows.Forms.Button btnBackUp;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Button btnMauDoChuaGiat;
        private System.Windows.Forms.TextBox txtDienThoaiCuaHang;
        private System.Windows.Forms.TextBox txtTenCuaHang;
        private System.Windows.Forms.Button btnMauDoDaTra;
        private System.Windows.Forms.Button btnMauDoGhiChu;
        private System.Windows.Forms.Button btnMauDoDaGiat;
        private System.Windows.Forms.CheckBox chkDungMaVach;
        private System.Windows.Forms.TextBox txtDiaChi;
        private System.Windows.Forms.Label label19;
		private System.Windows.Forms.TextBox txtMaVach;
		private System.Windows.Forms.CheckBox chkToanManHinh;
		private System.Windows.Forms.TextBox txtXoayVongDen;
		private System.Windows.Forms.TextBox txtXoayVongTu;
		private System.Windows.Forms.Label label21;
		private System.Windows.Forms.Label label20;
		private System.Windows.Forms.Label label23;
		private System.Windows.Forms.NumericUpDown nudPhiVanChuyen;
		private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Button btnMauDoPhieuHuy;
        private System.Windows.Forms.Label label24;
	}
}