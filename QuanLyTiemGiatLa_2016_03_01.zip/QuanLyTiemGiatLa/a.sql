use QuanLyTiemGiatLa;
go
--------------------------
alter table dbo.Phieu_Slot add ThoiDiemLuu varchar(50);
go
--------------------------
alter table dbo.Phieu_Slot_DaTra add ThoiDiemLuu varchar(50);
go
--------------------------
alter table dbo.Phieu add IsPhieuHuy bit;
go
--------------------------
--------------------------