﻿
using System;
namespace Entity
{
	public class InformationEntity
	{
		public Int64 PhieuChotKetGanNhat { get; set; }
	}
}
