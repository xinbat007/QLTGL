﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entity
{
	public class Common
	{
		public static String connectionString = "";
	}
}
